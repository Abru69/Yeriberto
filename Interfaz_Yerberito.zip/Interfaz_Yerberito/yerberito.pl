:- use_module(library(pce)).
use_module(library(pce_style_item)).

% Definir la ventana principal
crear_interfaz :-
    new(Menu, dialog('Sistema de Informacion de Plantas')),
    
    % Agregar una imagen a la ventana principal
    send(Menu, append, new(@imagen_planta, bitmap('C:/Interfaz_Yerberito/YERBERITO/yerberito.jpg'))),
    
    % Establecer la posicion de la imagen
    send(Menu, display, @imagen_planta, point(0, 0)),
    
    % Agregar opciones generales
    send(Menu, append, button(general, message(@prolog, menu_general))),
    
    % Agregar opciones de plantas especificas
    send(Menu, append, button(planta_especifica, message(@prolog, buscar_planta_especifica))),
    
    % Agregar opciones de enfermedad
    send(Menu, append, button(enfermedad, message(@prolog, buscar_enfermedad))),
    
    % Mostrar la ventana
    send(Menu, open).

% Menu general con subopciones
menu_general :-
    new(General, dialog('Opciones Generales')),
    send(General, append, button(plantas, message(@prolog, listar_plantas))),
    send(General, append, button(elementos, message(@prolog, listar_elementos))),
    send(General, append, button(medicamentos, message(@prolog, listar_medicamentos))),
    send(General, append, button(acciones_medicamentos, message(@prolog, listar_acciones_medicamentos))),
    send(General, append, button(significado, message(@prolog, listar_significado))),
    send(General, append, button(origenes, message(@prolog, listar_origenes))),
    send(General, append, button(botiquin, message(@prolog, listar_botiquin))),
    send(General, append, button(formas_preparacion, message(@prolog, listar_formas_preparacion))),
    send(General, open).

% Definir las acciones de los botones
listar_plantas :-
    new(Dialog, dialog('Listado de Plantas')),
    send(Dialog, append, new(Lista, list_browser)),
    % Definir las plantas
    forall(nombre(Planta, _), send(Lista, append, Planta)),
    % Mostrar la lista desplegable
    send(Dialog, append, Lista),
    % Mostrar el dialogo
    send(Dialog, open).


listar_elementos :-
    new(Dialog, dialog('Listado de Elementos')),
    send(Dialog, append, new(Lista, list_browser)),
    % Obtener todos los elementos sin duplicados
    findall(Elemento, contiene(_, Elemento), ListaElementos),
    sort(ListaElementos, ElementosSinDuplicados),
    % Mostrar los elementos en la lista desplegable
    forall(member(Elemento, ElementosSinDuplicados), send(Lista, append, Elemento)),
    % Mostrar la lista desplegable
    send(Dialog, append, Lista),
    % Mostrar el dialogo
    send(Dialog, open).

listar_medicamentos :-
    new(Dialog, dialog('Listado de Medicamentos')),
    send(Dialog, append, new(Lista, list_browser)),
    send(Lista, width, 40),
    % Obtener todos los medicamentos junto con la planta que los produce
    findall(Planta-Medicamento, medicamento(Planta, Medicamento), ListaPlantasMedicamentos),
    % Mostrar las plantas y los medicamentos en la lista desplegable
    forall(member(Planta-Medicamento, ListaPlantasMedicamentos),
           send(Lista, append, string('%s - %s', Planta, Medicamento))),
    % Mostrar la lista desplegable
    send(Dialog, append, Lista),
    % Mostrar el dialogo
    send(Dialog, open).

listar_acciones_medicamentos :-
new(Dialog, dialog('Efectos Secundarios de Medicamentos')),

% Crear el list_browser
new(Lista, list_browser),

% Configurar el tamaño del list_browser
send(Lista, width, 50),

% Agregar los efectos secundarios de cada medicamento a la lista
forall(efecto_secundario(Medicamento, Efectos),
       (
           send(Lista, append, Medicamento),
           forall(member(Efecto, Efectos),
                  send(Lista, append, string('\t%s', Efecto)))
       )),

% Agregar el list_browser al dialogo
send(Dialog, append, Lista),

% Mostrar el dialogo
send(Dialog, open).


listar_significado :-
new(Dialog, dialog('Diccionario de Terminos Medicos')),
    send(Dialog, size, size(500, 500)),

    % Crear un list_browser para mostrar los terminos
    new(Lista, list_browser),
    send(Lista, width, 50),

    % Agregar los terminos y sus significados al list_browser
    forall(significa(Termino, Significado),
           (
               send(Lista, append, string('%s: %s', Termino, Significado))
           )),

    % Agregar el list_browser al dialogo
    send(Dialog, append, new(Lab, label(title, 'Terminos Medicos')), right),
    send(Dialog, append, Lista),
    send(Lab, font, font(times, bold, 16)),

    % Mostrar el dialogo
    send(Dialog, open).


listar_origenes :-
    new(Dialog, dialog('Diccionario de Plantas por Origen')),
    send(Dialog, size, size(600, 200)),

    % Crear un list_browser para mostrar los datos
    new(Lista, list_browser),
    send(Lista, width, 80),

    % Obtener la lista de origenes unicos
    findall(Origen, (origen(_, Origen)), OrigenesList),
    sort(OrigenesList, OrigenesUnicos),

    % Rellenar el list_browser con los origenes y sus plantas
    forall(member(Origen, OrigenesUnicos),
           (
               send(Lista, append, dict_item(Origen, Origen)),
               findall(Planta, origen(Planta, Origen), Plantas),
               forall(member(Planta, Plantas),
                      send(Lista, append, dict_item('', string('\t%s', Planta))))
           )),

    % Agregar el list_browser al dialogo
    send(Dialog, append, Lista),

    % Mostrar el dialogo
    send(Dialog, open).

listar_botiquin :-
    new(Dialog, dialog('Botiquin de Plantas')),
    send(Dialog, size, size(400, 600)),

    % Crear un list_browser para mostrar los datos
    new(Lista, list_browser),


    % Rellenar el list_browser con las plantas del botiquin
    forall(botiquin(Planta),
           (
               send(Lista, append, dict_item('֎ ', string('%s', Planta)))
           )),

    % Agregar el list_browser al dialogo
    send(Dialog, append, Lista),

    % Mostrar el dialogo
    send(Dialog, open).

listar_formas_preparacion :-
new(Dialog, dialog('Diccionario de Preparaciones de Plantas')),

    % Crear un list_browser para mostrar las preparaciones
    new(Lista, list_browser),
    send(Lista, width, 80),

    % Agregar las preparaciones al list_browser
    forall(preparacion(Planta, Preparacion),
           (
               send(Lista, append, string('%s: %s', Planta, Preparacion))
           )),

    % Agregar el list_browser al dialogo
    send(Dialog, append, new(Lab, label(title, 'Preparaciones de Plantas')), right),
    send(Dialog, append, Lista),
    send(Lab, font, font(times, bold, 16)),

    % Mostrar el dialogo
    send(Dialog, open).
    

buscar_planta_especifica :-
    new(Dialogo, dialog('Buscador de Plantas')),
    send(Dialogo, append, new(CajaTexto, text_item('Nombre de la planta'))),
    send(Dialogo, append, new(CajaTexto1, text_item('Accion en el cuerpo'))),
    send(Dialogo, append, new(Boton, button('Buscar por planta', message(@prolog, buscar_planta, CajaTexto?selection)))),
    send(Dialogo, append, new(BotonAccion, button('Buscar por accion', message(@prolog, buscar_planta_por_accion, CajaTexto1?selection)))),
    send(Dialogo, append, new(Salir, button('Salir', message(Dialogo, destroy)))),
    send(Dialogo, open).


% Accion del boton de búsqueda
buscar_planta(Nombre) :-
    atom_string(AtomNombre, Nombre),
    writeln('Buscando planta con nombre: ' + AtomNombre), % Linea de depuracion
    (nombre(AtomNombre, NombreCientifico) ->
        obtener_informacion_planta(AtomNombre, Informacion),
        writeln('Mostrando informacion de la planta...'), % Linea de depuracion
        mostrar_informacion(AtomNombre, Informacion)
    ;
        writeln('Planta no encontrada.'), % Linea de depuracion
        send(@display, inform, string('La planta "%s" no fue encontrada.', Nombre))
    ).

obtener_informacion_planta(NombrePlanta, Informacion) :-
    findall(Item, contiene(NombrePlanta, Item), Contenidos),
    findall(Med, medicamento(NombrePlanta, Med), Medicamentos),
    findall(Enf, enfermedad(Enf, NombrePlanta), Enfermedades),
    findall(T, tipo(NombrePlanta, T), Acciones), % Obtener las acciones de la planta
    nombre(NombrePlanta, NombreCientifico),
    iman(NombrePlanta, Imagen),
    origen(NombrePlanta, Origen),
    preparacion(NombrePlanta, Preparacion),
    atomic_list_concat(Contenidos, ', ', ContenidosStr),
    atomic_list_concat(Medicamentos, ', ', MedicamentosStr),
    atomic_list_concat(Enfermedades, ', ', EnfermedadesStr),
    atomic_list_concat(Acciones, ', ', AccionesStr), % Convertir las acciones a string
    format(atom(Informacion), 'Nombre Cientifico: ~w\nContiene: ~w\nProduce: ~w\nCura: ~w\nOrigen: ~w\nPreparacion: ~w\nAccion: ~w', % Agregar la accion a la informacion
           [NombreCientifico, ContenidosStr, MedicamentosStr, EnfermedadesStr, Origen, Preparacion, AccionesStr]).


% Mostrar la informacion en la interfaz
mostrar_informacion(NombrePlanta, Informacion) :-
    new(DialogoInfo, dialog('Informacion de la Planta')),
    send(DialogoInfo, size, size(600, 400)),
    send(DialogoInfo, append, new(Texto, text(Informacion))),
    (iman(NombrePlanta, RutaImagen) ->
        new(Foto, bitmap(RutaImagen)),
        send(DialogoInfo, display, Foto, point(10, 140))
    ;
        true
        
    ),
    send(DialogoInfo, open).
buscar_planta_por_accion(Accion) :-
    atom_string(AtomAccion, Accion),
    findall(Planta, (nombre(Planta, _), tipo(Planta, AtomAccion)), Plantas),
    mostrar_resultados_accion(Plantas).

mostrar_resultados_accion([]) :-
    send(@display, inform, 'No se encontraron plantas con esa accion en el cuerpo.'),
    !.
mostrar_resultados_accion(Plantas) :-
    atomic_list_concat(Plantas, '\n', PlantasString),
    new(DialogoResultado, dialog('Resultados de Búsqueda')),
    send(DialogoResultado, size, size(400, 300)),
    send(DialogoResultado, append, new(Texto, text(PlantasString))),
    send(DialogoResultado, open).


buscar_enfermedad :-
    new(Dialogo, dialog('Buscador de Plantas y Enfermedades')),
    send(Dialogo, append, new(CajaTexto, text_item('Nombre de la planta'))),
    send(Dialogo, append, new(CajaTexto1, text_item('Nombre de la enfermedad'))),
    send(Dialogo, append, new(Boton1, button('Buscar Enfermedades por Planta', message(@prolog, buscar_enfermedades_por_planta, CajaTexto?selection)))),
    send(Dialogo, append, new(Boton2, button('Buscar Plantas por Enfermedad', message(@prolog, buscar_plantas_por_enfermedad, CajaTexto1?selection)))),
    send(Dialogo, append, new(Salir, button('Salir', message(Dialogo, destroy)))),
    send(Dialogo, open).

% Buscar enfermedades que cura una planta
buscar_enfermedades_por_planta(NombrePlanta) :-
    atom_string(AtomNombrePlanta, NombrePlanta),
    findall(Enfermedad, enfermedad(Enfermedad, AtomNombrePlanta), Enfermedades),
    ( Enfermedades \= [] ->
        atomic_list_concat(Enfermedades, ', ', EnfermedadesStr),
        format(atom(Mensaje), 'La planta "~w" cura las siguientes enfermedades: ~w', [NombrePlanta, EnfermedadesStr]),
        mostrar_resultado(Mensaje)
    ;
        format(atom(Mensaje), 'No se encontraron enfermedades curadas por la planta "~w".', [NombrePlanta]),
        mostrar_resultado(Mensaje)
    ).

% Buscar plantas que curan una enfermedad
buscar_plantas_por_enfermedad(NombreEnfermedad) :-
    atom_string(AtomNombreEnfermedad, NombreEnfermedad),
    findall(Planta, enfermedad(AtomNombreEnfermedad, Planta), Plantas),
    ( Plantas \= [] ->
        atomic_list_concat(Plantas, ', ', PlantasStr),
        format(atom(Mensaje), 'La enfermedad "~w" es curada por las siguientes plantas: ~w', [NombreEnfermedad, PlantasStr]),
        mostrar_resultado(Mensaje)
    ;
        format(atom(Mensaje), 'No se encontraron plantas que curen la enfermedad "~w".', [NombreEnfermedad]),
        mostrar_resultado(Mensaje)
    ).

% Mostrar el resultado en un dialogo
mostrar_resultado(Mensaje) :-
    new(DialogoResultado, dialog('Resultado')),
    send(DialogoResultado, append, new(Texto, label(texto, Mensaje))),
    send(DialogoResultado, append, new(Cerrar, button('Cerrar', message(DialogoResultado, destroy)))),
    send(DialogoResultado, open).

% Iniciar la interfaz al cargar el archivo
:- crear_interfaz.
nombre('Digitaria','digitalis purpura').
nombre('Opio','').
nombre('Ipeca','').
nombre('Nuez vomica','Strychnos nux vomica').
nombre('Eleboro blanco','').
nombre('Colchico','colchicum autumn').
nombre('Belladona','atropa belladona').
nombre('Quina','chinchona calisaya').
nombre('Cacao','').
nombre('Retama','spastium junoevm').
nombre('Coca','').
nombre('Peyote','').
nombre('Efedra','').
nombre('Barbasco','Diodcorea mexicana').
nombre('Nenufar amarillo','animal').
nombre('Name','').
nombre('Artemisa','').
nombre('Semilla de yute','').
nombre('Toloache','datura stramonium').
nombre('Eucalipto','eucaliptus globolus').
nombre('Rosal','rosa centifola').
nombre('Abrojo','tribulus cistoides').
nombre('Acacia','').
nombre('Acanto','acanthus mollis').
nombre('Aceitilla','bidens leucantha').
nombre('Achicoria','chicorium intybus').
nombre('Diente de leon','taraxacum officinale').
nombre('Doradilla','selaginella rupestris').
nombre('Ricino','ricinus communis').
nombre('Romero','rosmarinus off').
nombre('Sauce','').
nombre('Amapola','').
nombre('Manzanilla','matricaria chamomilla').

%contiene.
contiene('Digitaria','vitaminas').
contiene('Digitaria','hormonas').
contiene('Digitaria','minerales').
contiene('Digitaria','metaloides').
contiene('Digitaria','proteinas').
contiene('Digitaria','oligoelementos').
contiene('Digitaria','enzimas').
contiene('Digitaria','alcaloides').
contiene('Opio','vitaminas').
contiene('Opio','hormonas').
contiene('Opio','minerales').
contiene('Opio','metaloides').
contiene('Opio','proteinas').
contiene('Opio','oligoelementos').
contiene('Opio','enzimas').
contiene('Opio','alcaloides').
contiene('Ipeca','vitaminas').
contiene('Ipeca','hormonas').
contiene('Ipeca','minerales').
contiene('Ipeca','metaloides').
contiene('Ipeca','proteinas').
contiene('Ipeca','oligoelementos').
contiene('Ipeca','enzimas').
contiene('Ipeca','alcaloides').
contiene('Nuez vomica','vitaminas').
contiene('Nuez vomica','hormonas').
contiene('Nuez vomica','minerales').
contiene('Nuez vomica','metaloides').
contiene('Nuez vomica','proteinas').
contiene('Nuez vomica','oligoelementos').
contiene('Nuez vomica','enzimas').
contiene('Nuez vomica','alcaloides').
contiene('Eleboro blanco','vitaminas').
contiene('Eleboro blanco','hormonas').
contiene('Eleboro blanco','minerales').
contiene('Eleboro blanco','metaloides').
contiene('Eleboro blanco','proteinas').
contiene('Eleboro blanco','oligoelementos').
contiene('Eleboro blanco','enzimas').
contiene('Eleboro blanco','alcaloides').
contiene('Colchico','vitaminas').
contiene('Colchico','hormonas').
contiene('Colchico','minerales').
contiene('Colchico','metaloides').
contiene('Colchico','proteinas').
contiene('Colchico','oligoelementos').
contiene('Colchico','enzimas').
contiene('Colchico','alcaloides').
contiene('Belladona','vitaminas').
contiene('Belladona','hormonas').
contiene('Belladona','minerales').
contiene('Belladona','metaloides').
contiene('Belladona','proteinas').
contiene('Belladona','oligoelementos').
contiene('Belladona','enzimas').
contiene('Belladona','alcaloides').
contiene('Quina','vitaminas').
contiene('Quina','hormonas').
contiene('Quina','minerales').
contiene('Quina','metaloides').
contiene('Quina','proteinas').
contiene('Quina','oligoelementos').
contiene('Quina','enzimas').
contiene('Quina','alcaloides').
contiene('Cacao','vitaminas').
contiene('Cacao','hormonas').
contiene('Cacao','minerales').
contiene('Cacao','metaloides').
contiene('Cacao','proteinas').
contiene('Cacao','oligoelementos').
contiene('Cacao','enzimas').
contiene('Cacao','alcaloides').
contiene('Retama','vitaminas').
contiene('Retama','hormonas').
contiene('Retama','minerales').
contiene('Retama','metaloides').
contiene('Retama','proteinas').
contiene('Retama','oligoelementos').
contiene('Retama','enzimas').
contiene('Retama','alcaloides').
contiene('Coca','vitaminas').
contiene('Coca','hormonas').
contiene('Coca','minerales').
contiene('Coca','metaloides').
contiene('Coca','proteinas').
contiene('Coca','oligoelementos').
contiene('Coca','enzimas').
contiene('Coca','alcaloides').
contiene('Peyote','vitaminas').
contiene('Peyote','hormonas').
contiene('Peyote','minerales').
contiene('Peyote','metaloides').
contiene('Peyote','proteinas').
contiene('Peyote','oligoelementos').
contiene('Peyote','enzimas').
contiene('Peyote','alcaloides').
contiene('Efedra','vitaminas').
contiene('Efedra','hormonas').
contiene('Efedra','minerales').
contiene('Efedra','metaloides').
contiene('Efedra','proteinas').
contiene('Efedra','oligoelementos').
contiene('Efedra','enzimas').
contiene('Efedra','alcaloides').
contiene('Barbasco','vitaminas').
contiene('Barbasco','hormonas').
contiene('Barbasco','minerales').
contiene('Barbasco','metaloides').
contiene('Barbasco','proteinas').
contiene('Barbasco','oligoelementos').
contiene('Barbasco','enzimas').
contiene('Barbasco','alcaloides').
contiene('Nenufar amarillo','vitaminas').
contiene('Nenufar amarillo','hormonas').
contiene('Nenufar amarillo','minerales').
contiene('Nenufar amarillo','metaloides').
contiene('Nenufar amarillo','proteinas').
contiene('Nenufar amarillo','oligoelementos').
contiene('Nenufar amarillo','enzimas').
contiene('Nenufar amarillo','alcaloides').
contiene('Name','vitaminas').
contiene('Name','hormonas').
contiene('Name','minerales').
contiene('Name','metaloides').
contiene('Name','proteinas').
contiene('Name','oligoelementos').
contiene('Name','enzimas').
contiene('Name','alcaloides').
contiene('Artemisa','vitaminas').
contiene('Artemisa','hormonas').
contiene('Artemisa','minerales').
contiene('Artemisa','metaloides').
contiene('Artemisa','proteinas').
contiene('Artemisa','oligoelementos').
contiene('Artemisa','enzimas').
contiene('Artemisa','alcaloides').
contiene('Semilla de yute','vitaminas').
contiene('Semilla de yute','hormonas').
contiene('Semilla de yute','minerales').
contiene('Semilla de yute','metaloides').
contiene('Semilla de yute','proteinas').
contiene('Semilla de yute','oligoelementos').
contiene('Semilla de yute','enzimas').
contiene('Semilla de yute','alcaloides').
contiene('Toloache','vitaminas').
contiene('Toloache','hormonas').
contiene('Toloache','minerales').
contiene('Toloache','metaloides').
contiene('Toloache','proteinas').
contiene('Toloache','oligoelementos').
contiene('Toloache','enzimas').
contiene('Toloache','alcaloides').
contiene('Eucalipto','vitaminas').
contiene('Eucalipto','hormonas').
contiene('Eucalipto','minerales').
contiene('Eucalipto','metaloides').
contiene('Eucalipto','proteinas').
contiene('Eucalipto','oligoelementos').
contiene('Eucalipto','enzimas').
contiene('Eucalipto','alcaloides').
contiene('Rosal','vitaminas').
contiene('Rosal','hormonas').
contiene('Rosal','minerales').
contiene('Rosal','metaloides').
contiene('Rosal','proteinas').
contiene('Rosal','oligoelementos').
contiene('Rosal','enzimas').
contiene('Rosal','alcaloides').
contiene('Abrojo','vitaminas').
contiene('Abrojo','hormonas').
contiene('Abrojo','minerales').
contiene('Abrojo','metaloides').
contiene('Abrojo','proteinas').
contiene('Abrojo','oligoelementos').
contiene('Abrojo','enzimas').
contiene('Abrojo','alcaloides').
contiene('Acacia','vitaminas').
contiene('Acacia','hormonas').
contiene('Acacia','minerales').
contiene('Acacia','metaloides').
contiene('Acacia','proteinas').
contiene('Acacia','oligoelementos').
contiene('Acacia','enzimas').
contiene('Acacia','alcaloides').
contiene('Acanto','vitaminas').
contiene('Acanto','hormonas').
contiene('Acanto','minerales').
contiene('Acanto','metaloides').
contiene('Acanto','proteinas').
contiene('Acanto','oligoelementos').
contiene('Acanto','enzimas').
contiene('Acanto','alcaloides').
contiene('Aceitilla','vitaminas').
contiene('Aceitilla','hormonas').
contiene('Aceitilla','minerales').
contiene('Aceitilla','metaloides').
contiene('Aceitilla','proteinas').
contiene('Aceitilla','oligoelementos').
contiene('Aceitilla','enzimas').
contiene('Aceitilla','alcaloides').
contiene('Achicoria','vitaminas').
contiene('Achicoria','hormonas').
contiene('Achicoria','minerales').
contiene('Achicoria','metaloides').
contiene('Achicoria','proteinas').
contiene('Achicoria','oligoelementos').
contiene('Achicoria','enzimas').
contiene('Achicoria','alcaloides').
contiene('Diente de leon','alcaloides').
contiene('Doradilla','vitaminas').
contiene('Doradilla','hormonas').
contiene('Doradilla','minerales').
contiene('Doradilla','metaloides').
contiene('Doradilla','proteinas').
contiene('Doradilla','oligoelementos').
contiene('Doradilla','enzimas').
contiene('Doradilla','alcaloides').
contiene('Ricino','vitaminas').
contiene('Ricino','hormonas').
contiene('Ricino','minerales').
contiene('Ricino','metaloides').
contiene('Ricino','proteinas').
contiene('Ricino','oligoelementos').
contiene('Ricino','enzimas').
contiene('Ricino','alcaloides').
contiene('Romero','vitaminas').
contiene('Romero','hormonas').
contiene('Romero','minerales').
contiene('Romero','metaloides').
contiene('Romero','proteinas').
contiene('Romero','oligoelementos').
contiene('Romero','enzimas').
contiene('Romero','alcaloides').
contiene('Sauce','vitaminas').
contiene('Sauce','hormonas').
contiene('Sauce','minerales').
contiene('Sauce','metaloides').
contiene('Sauce','proteinas').
contiene('Sauce','oligoelementos').
contiene('Sauce','enzimas').
contiene('Sauce','alcaloides').
contiene('Amapola','vitaminas').
contiene('Amapola','hormonas').
contiene('Amapola','minerales').
contiene('Amapola','metaloides').
contiene('Amapola','proteinas').
contiene('Amapola','oligoelementos').
contiene('Amapola','enzimas').
contiene('Amapola','alcaloides').
contiene('Manzanilla','clorofila').
contiene('Manzanilla','azulina').
contiene('Manzanilla','tanatos').
contiene('Manzanilla','oxalatos').
contiene('Manzanilla','resina').

medicamento('Digitaria','Digitalina').
medicamento('Opio','Morfina').
medicamento('Opio','Codeina').
medicamento('Ipeca','Emetina').
medicamento('Nuez vomica','Estricnina').
medicamento('Eleboro blanco','Veratrina').
medicamento('Colchico','Colchicina').
medicamento('Belladona','Atropina').
medicamento('Quina','Quinina').
medicamento('Cacao','Teobromina').
medicamento('Retama','Esparteina').
medicamento('Coca','Cocaina').
medicamento('Peyote','Mezcalina').
medicamento('Efedra','Efedrina').
medicamento('Barbasco','Hormonas').
medicamento('Nenufar amarillo','Lutenurina').
medicamento('Name','Diosponina').
medicamento('Artemisa','Tauremisina').
medicamento('Semilla de yute','Olitorisida').
medicamento('Toloache','Acido lisergico').
medicamento('Eucalipto','Eucaliptol').
medicamento('Rosal','Vitamina C').
medicamento('Rosal','Quercitrina').


% Hechos sobre los efectos secundarios de los medicamentos
efecto_secundario('Digitalina', ['Nauseas', 'Vomitos', 'Dolores de cabeza', 'Confusion', 'Vision borrosa', 'Ritmo cardiaco irregular', 'Intoxicacion digital']).
efecto_secundario('Morfina', ['Somnolencia', 'Mareos', 'Nauseas', 'Vomitos', 'Estreñimiento', 'Depresion respiratoria', 'Adiccion']).
efecto_secundario('Codeina', ['Somnolencia', 'Mareos', 'Nauseas', 'Vomitos', 'Estreñimiento', 'Depresion respiratoria', 'Adiccion']).
efecto_secundario('Emetina', ['Nauseas', 'Vomitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Daño al corazon en dosis altas']).
efecto_secundario('Estricnina', ['Convulsiones', 'Rigidez muscular extrema', 'Aumento de la presion arterial', 'Taquicardia', 'Muerte']).
efecto_secundario('Veratrina', ['Nauseas', 'Vomitos', 'Dolor abdominal', 'Diarrea', 'Mareos', 'Debilidad muscular', 'Convulsiones en dosis altas']).
efecto_secundario('Colchicina', ['Nauseas', 'Vomitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Disminucion de los globulos blancos', 'Neuropatia periferica']).
efecto_secundario('Atropina', ['Boca seca', 'Vision borrosa', 'Aumento de la frecuencia cardiaca', 'Retencion urinaria', 'Estreñimiento', 'Confusion', 'Alucinaciones']).
efecto_secundario('Quinina', ['Trastornos del ritmo cardiaco', 'Sordera', 'Vision borrosa', 'Nauseas', 'Vomitos', 'Diarrea', 'Dolor de cabeza', 'Sudoracion', 'Erupciones cutaneas']).
efecto_secundario('Teobromina', ['Nerviosismo', 'Irritabilidad', 'Insomnio', 'Taquicardia', 'Aumento de la miccion', 'Temblores musculares']).
efecto_secundario('Esparteina', ['Mareos', 'Confusion', 'Debilidad muscular', 'Nauseas', 'Vomitos', 'Diarrea', 'Disminucion de la presion arterial', 'Arritmias cardiacas']).
efecto_secundario('Cocaina', ['Aumento de la frecuencia cardiaca', 'Presion arterial alta', 'Agitacion', 'Ansiedad', 'Convulsiones', 'Accidentes cerebrovasculares', 'Infartos de miocardio', 'Muerte']).
efecto_secundario('Mezcalina', ['Nauseas', 'Vomitos', 'Aumento de la presion arterial', 'Dilatacion de las pupilas', 'Alucinaciones', 'Cambios en la percepcion sensorial']).
efecto_secundario('Efedrina', ['Nerviosismo', 'Agitacion', 'Insomnio', 'Aumento de la presion arterial', 'Palpitaciones cardiacas', 'Temblores musculares', 'Sudoracion', 'Mareos']).
efecto_secundario('Hormonas', ['Cambios en el estado de animo', 'Aumento de peso', 'Retencion de liquidos', 'Cambios en la libido', 'Riesgo aumentado de coagulos sanguineos']).
efecto_secundario('Lutenurina', ['Irritacion en el lugar de la inyeccion', 'Dolor de cabeza', 'Cambios en el estado de animo', 'Cambios en el apetito', 'Acne', 'Aumento del vello facial']).
efecto_secundario('Diosponina', ['Malestar estomacal', 'Diarrea', 'Nauseas', 'Vomitos', 'Dolor de cabeza', 'Mareos', 'Erupciones cutaneas']).
efecto_secundario('Tauremisina', ['Dolor de cabeza', 'Mareos', 'Nauseas', 'Vomitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Temblores']).
efecto_secundario('Olitorisida', ['Irritacion en el tracto gastrointestinal', 'Nauseas', 'Vomitos', 'Diarrea', 'Dolor abdominal', 'Mareos']).
efecto_secundario('acido lisergico', ['Alucinaciones', 'Cambios en la percepcion sensorial', 'Ansiedad', 'Paranoia', 'Aumento del ritmo cardiaco', 'Aumento de la presion arterial']).
efecto_secundario('Eucaliptol', ['Irritacion en la garganta y los pulmones', 'Nauseas', 'Vomitos', 'Diarrea', 'Convulsiones en dosis altas']).
efecto_secundario('Vitamina C', ['Malestar estomacal', 'Diarrea', 'Nauseas', 'Vomitos', 'Dolor de cabeza', 'Acidez estomacal', 'Riesgo aumentado de calculos renales']).
efecto_secundario('Quercitrina', ['Nauseas', 'Vomitos', 'Diarrea', 'Dolor abdominal', 'Reacciones alergicas']).


significa('Afrodisiaca','exita el apetito sexual').
significa('Analgesica','quita o modera el dolor').
significa('Anestesica','insensibiliza el cuerpo').
significa('Antidiarreica','controla diarreas').
significa('Antiespasmodica','controla espasmos nerviosos').
significa('Antiflogistica','ayuda con inflamaciones').
significa('Antipiretica','quita la fiebre').
significa('Antiseptica','mata los tejidos').
significa('Aperitiva','deseo de comer').
significa('Astringente','contrae los tejidos').
significa('Carminativa','evita formacion de gases').
significa('Colagoga','ayuda a expulsar la bilis').
significa('Depurativa','limpia y purifica la sangre').
significa('Diaforetica','provoca sudoracion como cochino').
significa('Digestiva','favorece a la digestion').
significa('Diuretica','provoca la orina').
significa('Emetica','provoca nauseas y vomitos').
significa('Emenagoga','activa la menstruacion').
significa('Estupefaciente','ayuda a tranquilizar').
significa('Hemostatica','detiene las hemorragias').
significa('Hepatica','ayuda al higado').
significa('Laxante','purga sin provocar diarrea').
significa('Pectoral','ayuda al pecho').
significa('Sedante','calma dolores intestinales').
significa('Tonica','fortalece el organismo').
significa('Toxica','es venenosa').
significa('Vermifuga','expulsa gusanos intestinales').
significa('Vulneraria','cura llagas y heridas').

% Definicion de la relacion origen/2 sin acentos y caracteres especiales
origen('Digitaria', 'Africa, Asia, America, Australia').
origen('Digitalis purpura', 'Europa occidental y central').
origen('Opio', 'Suroeste de Asia').
origen('Ipeca', 'America del Sur, principalmente Brasil').
origen('Nuez vomica', 'Sur de Asia y sudeste asiatico').
origen('Eleboro blanco', 'Europa, Asia y America del Norte').
origen('Colchico', 'Europa y partes de Asia occidental').
origen('Belladona', 'Europa, Asia occidental y norte de Africa').
origen('Quina', 'America del Sur, especialmente de los Andes').
origen('Cacao', 'Region amazonica de Sudamerica, tambien se cultiva en otras partes tropicales').
origen('Retama', 'Mediterraneo occidental, sur de Espana y norte de Africa').
origen('Coca', 'America del Sur, especialmente de los Andes').
origen('Peyote', 'Norte de Mexico y suroeste de Estados Unidos').
origen('Efedra', 'America del Norte, America del Sur, Europa, Africa y Asia').
origen('Barbasco', 'Mexico y America Central').
origen('Nenufar amarillo', 'America, Europa, Asia y Africa').
origen('Name', 'Africa y Asia tropical').
origen('Artemisa', 'Europa, Asia, Africa y America del Norte').
origen('Semilla de yute', 'Subcontinente indio').
origen('Toloache', 'America del Norte y America del Sur').
origen('Eucalipto', 'Australia').
origen('Rosal', 'Asia').
origen('Abrojo', 'America del Sur').
origen('Acanto', 'Region mediterranea').
origen('Aceitilla', 'America, especialmente America del Norte y America Central').
origen('Achicoria', 'Europa, Asia y Africa').
origen('Diente de leon', 'Europa y Asia').
origen('Doradilla', 'America del Norte').
origen('Ricino', 'Africa, Asia, ahora se encuentra en todo el mundo').
origen('Romero', 'Region mediterranea').
origen('Sauce', 'Regiones templadas y frias del hemisferio norte').
origen('Amapola', 'Suroeste de Asia').
origen('Manzanilla', 'Europa y Asia occidental').

botiquin('Anis estrella').
botiquin('Menta').
botiquin('Arnica').
botiquin('Salvia').
botiquin('Tila').
botiquin('Eucalipto').
botiquin('Yierbabuena').
botiquin('Manzanilla').
botiquin('Cola de caballo').
botiquin('Romero').
botiquin('Toronjil').
botiquin('Sanguinaria').
botiquin('Linaza').
botiquin('Hamamelis').
botiquin('Zarzaparrilla').
botiquin('Boldo').
botiquin('Diente de leon').
botiquin('Azahar').
botiquin('Malva').
botiquin('Marrubio').
botiquin('Rosal').

preparacion('Digitaria', 'Infusion: Hervir 1 cucharadita de planta seca en una taza de agua por 10 minutos.').
preparacion('Digitalis purpura', 'Decoccion: Hervir 1 cucharadita de planta seca en una taza de agua por 15 minutos.').
preparacion('Opio', 'Extracto: Utilizar bajo supervision medica.').
preparacion('Ipeca', 'Jarabe: Mezclar con azucar y agua para hacer un jarabe expectorante.').
preparacion('Nuez vomica', 'Tintura: Macerar 50g de semillas en 250ml de alcohol por 2 semanas.').
preparacion('Eleboro blanco', 'Infusion: Hervir 1 cucharadita de planta seca en una taza de agua por 10 minutos.').
preparacion('Colchico', 'Tintura: Macerar 50g de bulbos en 250ml de alcohol por 2 semanas.').
preparacion('Belladona', 'Extracto: Utilizar bajo supervision medica.').
preparacion('Quina', 'Decoccion: Hervir 1 cucharadita de corteza en una taza de agua por 15 minutos.').
preparacion('Cacao', 'Bebida: Mezclar con agua caliente y azucar para preparar chocolate.').
preparacion('Retama', 'Infusion: Hervir 1 cucharadita de flores secas en una taza de agua por 10 minutos.').
preparacion('Coca', 'Masticar: Las hojas se mastican tradicionalmente.').
preparacion('Peyote', 'Masticar: Los botones se mastican tradicionalmente.').
preparacion('Efedra', 'Decoccion: Hervir 1 cucharadita de planta seca en una taza de agua por 15 minutos.').
preparacion('Barbasco', 'Infusi0n: Hervir 1 cucharadita de raices secas en una taza de agua por 10 minutos.').
preparacion('Nenufar amarillo', 'Decoccion: Hervir 1 cucharadita de rizoma en una taza de agua por 15 minutos.').
preparacion('Name', 'Cocido: Hervir los tuberculos hasta que esten tiernos.').
preparacion('Artemisa', 'Infusion: Hervir 1 cucharadita de planta seca en una taza de agua por 10 minutos.').
preparacion('Semilla de yute', 'Infusion: Hervir 1 cucharadita de semillas en una taza de agua por 10 minutos.').
preparacion('Toloache', 'Infusion: Hervir 1 cucharadita de hojas secas en una taza de agua por 10 minutos.').
preparacion('Eucalipto', 'Inhalacion: Hervir hojas en agua e inhalar el vapor.').
preparacion('Rosal', 'Infusion: Hervir 1 cucharadita de petalos secos en una taza de agua por 10 minutos.').
preparacion('Abrojo', 'Infusion: Hervir 1 cucharadita de frutos secos en una taza de agua por 10 minutos.').
preparacion('Acacia', 'Infusion: Hervir 1 cucharadita de goma en una taza de agua por 10 minutos.').
preparacion('Acanto', 'Infusion: Hervir 1 cucharadita de hojas secas en una taza de agua por 10 minutos.').
preparacion('Aceitilla', 'Infusion: Hervir 1 cucharadita de hojas secas en una taza de agua por 10 minutos.').
preparacion('Achicoria', 'Decoccion: Hervir 1 cucharadita de raices en una taza de agua por 15 minutos.').
preparacion('Diente de leon', 'Infusion: Hervir 1 cucharadita de hojas secas en una taza de agua por 10 minutos.').
preparacion('Doradilla', 'Infusion: Hervir 1 cucharadita de planta seca en una taza de agua por 10 minutos.').
preparacion('Ricino', 'Aceite: Extraer aceite de las semillas y usar con precaucion.').
preparacion('Romero', 'Infusion: Hervir 1 cucharadita de hojas secas en una taza de agua por 10 minutos.').
preparacion('Sauce', 'Decoccion: Hervir 1 cucharadita de corteza en una taza de agua por 15 minutos.').
preparacion('Amapola', 'Infusion: Hervir 1 cucharadita de petalos secos en una taza de agua por 10 minutos.').
preparacion('Manzanilla', 'Infusion: Hervir 1 cucharadita de flores secas en una taza de agua por 10 minutos.').



enfermedad('Absesos','Malva').
enfermedad('Abseso Hepatico','Zarzaparilla').
enfermedad('Acidez Estomacal','Anis').
enfermedad('Acidez Estomacal','Perejil').
enfermedad('Acido Urico','Sanguinaria').
enfermedad('Acido Urico','Limon').
enfermedad('Acido Urico','Sauco').
enfermedad('Acne','Arnica').
enfermedad('Aftas','Llanten').
enfermedad('Aftas','Fenogreco').
enfermedad('Aftas','Zarzamora').
enfermedad('Agotamiento','Salvia').
enfermedad('Agotamiento','Tilo').
enfermedad('Agotamiento','Valeriana').
enfermedad('Agruras','Yerbabuena').
enfermedad('Agruras','Manzanilla').
enfermedad('Agruras','Jugo de limon o toronja').
enfermedad('Albuminaria','Pinguica').
enfermedad('Albuminaria','Quina Roja').
enfermedad('Albuminaria','Encino Rojo').
enfermedad('Alcoholismo','Pimiento').
enfermedad('Almorranas','Salvia').
enfermedad('Almorranas','Hamamelis').
enfermedad('Almorranas','Sanguinaria').
enfermedad('Almorranas','Cola de caballo').
enfermedad('Almorranas','Arnica').
enfermedad('Almorranas','Sauco').
enfermedad('Anemia','Ajenjo').
enfermedad('Anemia','Germen de trigo').
enfermedad('Anemia','Quina').
enfermedad('Anemia','Canela').
enfermedad('Anemia','Alholva').
enfermedad('Anginas','Eucalipto').
enfermedad('Anginas','Cebada').
enfermedad('Anginas','Salvia').
enfermedad('Anginas','Tabachin').
enfermedad('Anginas','Borraja').
enfermedad('Anorexia','Ajenjo').
enfermedad('Anorexia','Genciana').
enfermedad('Anorexia','Yerbabuena').
enfermedad('Arterosclerosis','Limon').
enfermedad('Arterosclerosis','Genciana').
enfermedad('Arterosclerosis','Cardo').
enfermedad('Arterosclerosis','Zarzaparilla').
enfermedad('Arterosclerosis','Arnica').
enfermedad('Arterosclerosis','Cchicalote').
enfermedad('Arterosclerosis','Alcamfor').
enfermedad('Arterosclerosis','Toronja').
enfermedad('Artritis','Limon').
enfermedad('Artritis','Genciana').
enfermedad('Artritis','Cardo').
enfermedad('Artritis','Zarzaparilla').
enfermedad('Artritis','Arnica').
enfermedad('Artritis','Cchicalote').
enfermedad('Artritis','Alcamfor').
enfermedad('Artritis','Toronja').
enfermedad('Asma','Eucalipto').
enfermedad('Asma','Marrubio').
enfermedad('Asma','Toloache').
enfermedad('Asma','Oregano').
enfermedad('Asma','Salvia').
enfermedad('Atonia Estomacal','Lupulu').
enfermedad('Atonia Estomacal','Eucalipto').
enfermedad('Atonia Estomacal','Cuasia').
enfermedad('Bazo','Uva').
enfermedad('Bazo','Cerezo').
enfermedad('Inflamacion de Boca','Malva').
enfermedad('Inflamacion de Boca','Rosal').
enfermedad('Inflamacion de Boca','Limon').
enfermedad('Inflamacion de Boca','Salvia').
enfermedad('Estomatitis de Boca','Rosal').
enfermedad('Estomatitis de Boca','Encina').
enfermedad('Estomatitis de Boca','Salvia').
enfermedad('Estomatitis de Boca','Zarzamora').
enfermedad('Bronquitis','Eucalipto').
enfermedad('Bronquitis','Borraja').
enfermedad('Bronquitis','Anacahuite').
enfermedad('Bronquitis','Gordolobo').
enfermedad('Bronquitis','Tilo').
enfermedad('Bronquitis','Benjui').
enfermedad('Bronquitis','Marrubio').
enfermedad('Bronquitis','Rabano').
enfermedad('Bronconeumonia','Gordolobo').
enfermedad('Bronconeumonia','Eucalipto').
enfermedad('Bronconeumonia','Ipecacuana').
enfermedad('Bronconeumonia','Mostaza').
enfermedad('Caida del cabello','Ortiga').
enfermedad('Caida del cabello','Espinosilla').
enfermedad('Caida del cabello','Marrubio').
enfermedad('Caida del cabello','Romero').
enfermedad('Calambres','Anis').
enfermedad('Calambres','Tila').
enfermedad('Calambres','Manzanilla').
enfermedad('Calambres','Ajenjo').
enfermedad('Calculos biliares','Diente de leon').
enfermedad('Calculos biliares','Aceite de oliva').
enfermedad('Calculos biliares','Retama').
enfermedad('Calculos renales','Cabellos de elote').
enfermedad('Calculos renales','Pinguica').
enfermedad('Calculos renales','Cola de caballo').
enfermedad('Callos','Ajo').
enfermedad('Callos','Cebolla').
enfermedad('Caries','Hiedra').
enfermedad('Caries','Cola de caballo').
enfermedad('Caspa','Ortiga').
enfermedad('Caspa','Limon').
enfermedad('Caspa','Romero').
enfermedad('Cancer de utero','Cuachalalate').
enfermedad('Cancer de utero','Llanten').
enfermedad('Cancer de utero','Siempreviva').
enfermedad('Ciatica','Mastuerzo').
enfermedad('Ciatica','Higuera').
enfermedad('Ciatica','Sauce').
enfermedad('Circulacion','Toronjil').
enfermedad('Circulacion','Sanguinaria').
enfermedad('Circulacion','Salvia').
enfermedad('Circulacion','Hamamelis').
enfermedad('Cistitis','Cola de caballo').
enfermedad('Cistitis','Doradilla').
enfermedad('Cistitis','Ajo').
enfermedad('Cistitis','Cabellos de elote').
enfermedad('Colicos','Menta').
enfermedad('Colicos','Hinojo').
enfermedad('Colicos','Manzanilla').
enfermedad('Colicos','Toronjil').
enfermedad('Colicos','Boldo').
enfermedad('Colitis','Linaza').
enfermedad('Colitis','Anis').
enfermedad('Colitis','Romero').
enfermedad('Colitis','Cola de caballo').
enfermedad('Colicos','Chilantro').
enfermedad('Colitis','Linaza').
enfermedad('Colitis','Anis').
enfermedad('Colitis','Romero').
enfermedad('Colitis','Cola de caballo').
enfermedad('Contusiones','Arnica').
enfermedad('Contusiones','Hamamelis').
enfermedad('Contusiones','Laurel').
enfermedad('Contusiones','Brionia').
enfermedad('Constipacion', 'Chichigua').
enfermedad('Contusiones','Arnica').
enfermedad('Contusiones','Hamamelis').
enfermedad('Contusiones','Laurel').
enfermedad('Contusiones','Brionia').
enfermedad('Tonico para el Corazon','Digitaria').
enfermedad('Tonico para el Corazon','Salvia').
enfermedad('Tonico para el Corazon','Nuez de kcla').
enfermedad('Tonico para el Corazon','Tejocote').
enfermedad('Depurativos de la sangre','Achicoria').
enfermedad('Depurativos de la sangre','Diente de leon').
enfermedad('Depurativos de la sangre','Apio').
enfermedad('Depurativos de la sangre','Sanguinaria').
enfermedad('Depurativos de la sangre','Zarzaparilla').
enfermedad('Depurativos de la sangre','Berro').
enfermedad('Diabetes','Matarique').
enfermedad('Diabetes','Tronadora').
enfermedad('Diabetes','Eucalipto').
enfermedad('Diabetes','Damiana').
enfermedad('Diarrea cronica','Capulin').
enfermedad('Diarrea cronica','Mezquite').
enfermedad('Diarrea cronica','Tlachichinole').
enfermedad('Diarrea por irritacion','Linaza').
enfermedad('Diarrea por irritacion','Membrillo').
enfermedad('Diarrea por irritacion','Arroz').
enfermedad('Diarrea por irritacion','Cebada').
enfermedad('Diarrea por inflamacion','Guayaba').
enfermedad('Diarrea por inflamacion','Añbahaca').
enfermedad('Diarrea por inflamacion','Granada').
enfermedad('Diarrea verdosa','Manzanilla').
enfermedad('Diarrea verdosa','Simonilla').
enfermedad('Diarrea verdosa','Siempreviva').
enfermedad('Diarrea con sangre','Chaparro amargoso').
enfermedad('Diarrea con sangre','Muicle').
enfermedad('Diarrea con sangre','Monacillo').
enfermedad('Diftera','Limon').
enfermedad('Diftera','Naranja').
enfermedad('Disenteria','Tamarindo').
enfermedad('Disenteria','Chaparro amargoso').
enfermedad('Disenteria','Ipecacuana').
enfermedad('Disenteria','Cedron').
enfermedad('Dispepsia','Anis').
enfermedad('Dispepsia','Menta').
enfermedad('Dispepsia','Yerbabuena').
enfermedad('Dispepsia','Diente').
enfermedad('Dispepsia','Te limon').
enfermedad('Dispepsia','Quina').
enfermedad('Dispepsia','Genciana').
enfermedad('Dispepsia','Tabaquillo').
enfermedad('Dispepsia','Ruibardo').
enfermedad('Dispepsia con dolor','Anis estrella').
enfermedad('Dispepsia con dolor','Valeriana').
enfermedad('Dispepsia con dolor','Manzanilla').
enfermedad('Dolores musculares','Alcanfor').
enfermedad('Empacho','Tamarindo').
enfermedad('Enteritis','Linaza').
enfermedad('Enteritis','Cedron').
enfermedad('Enteritis','Llanten').
enfermedad('Epilepsia','Valeriana').
enfermedad('Epistaxis hemorragia nasal','Hierba de pollo').
enfermedad('Epistaxis hemorragia nasal','Cebolla').
enfermedad('Epistaxis hemorragia nasal','Perejil').
enfermedad('Erisipela','Sauco').
enfermedad('Erisipela','Hiedra').
enfermedad('Erisipela','Zanahoria').
enfermedad('Escarlatina','Borraja').
enfermedad('Escarlatina','Sauco').
enfermedad('Escarlatina','Cebolla').
enfermedad('Escorbuto','Ajo').
enfermedad('Escorbuto','Limon').
enfermedad('Escorbuto','Berro').
enfermedad('Escorbuto','Cebolla').
enfermedad('Escorbuto','Geranio').
enfermedad('Estreñimiento','Ciruela').
enfermedad('Estreñimiento','Linaza').
enfermedad('Estreñimiento','Chia').
enfermedad('Estreñimiento','Tamarindo').
enfermedad('Estreñimiento','Agar-agar').
enfermedad('Faringitis','Eucalipto').
enfermedad('Faringitis','Lavanda').
enfermedad('Faringitis','Anacahuite').
enfermedad('Flatulencias','Apio').
enfermedad('Flatulencias','Tomillo').
enfermedad('Flatulencias','Perejil').
enfermedad('Flatulencias','Anis estrella').
enfermedad('Flatulencias','Hinojo').
enfermedad('Flatulencias','Toronjil').
enfermedad('Flatulencias','Romero').
enfermedad('Flatulencias','Ruibarbo').
enfermedad('Flatulencias','Ruda').
enfermedad('Flatulencias','Menta').
enfermedad('Flebitis','Armica').
enfermedad('Flebitis','Alfalfa').
enfermedad('Flebitis','Lino').
enfermedad('Flebitis','Malvavisco').
enfermedad('Flebitis','Romero').
enfermedad('Flebitis','Quina').
enfermedad('Flemas','Genciana').
enfermedad('Flemas','Oregano').
enfermedad('Forunculos','Fenogreco').
enfermedad('Forunculos','Malvavisco').
enfermedad('Forunculos','Hiedra').
enfermedad('Gastralgia','Manzanilla').
enfermedad('Gastralgia','Anis estrella').
enfermedad('Gonorrea','Cola de caballo').
enfermedad('Gonorrea','Doradilla').
enfermedad('Gonorrea','Zarzaparrilla').
enfermedad('Gota','Apio').
enfermedad('Gota','Cerezo').
enfermedad('Gota','Limon').
enfermedad('Gota','Pino').
enfermedad('Gota','Alcanfor').
enfermedad('Gota','Aconito').
enfermedad('Gota','Belladona').
enfermedad('Gota','Beleño').
enfermedad('Gota','Colchico').
enfermedad('Gota','Chicalote').
enfermedad('Grietas del ano','Encina').
enfermedad('Grietas del pezon','Encina').
enfermedad('Grietas del pezon','Nogal').
enfermedad('Grietas del pezon','Milenrama').
enfermedad('Gripe','Eucalipto').
enfermedad('Gripe','Limon').
enfermedad('Gripe','Quina').
enfermedad('Gripe','Zarzaparrilla').
enfermedad('Gripe','Calendula').
enfermedad('Halitosis','Hinojo').
enfermedad('Halitosis','Menta').
enfermedad('Hemorragia interna','Mastuerzo').
enfermedad('Hemorragia interna','Ortiga').
enfermedad('Hemorragia interna','Rosal').
enfermedad('Hepatitia','Retama').
enfermedad('Hepatitia','Boldo').
enfermedad('Hepatitia','Alcachofa').
enfermedad('Hepatitia','Prodigiosa').
enfermedad('Hepatitia','Cascara sagrada').
enfermedad('Hernia','Helecho').
enfermedad('Hernia','Ricino').
enfermedad('Hernia','Tabaco').
enfermedad('Herpes','Linaza').
enfermedad('Herpes','Llanten').
enfermedad('Herida','Arnica').
enfermedad('Herida','Hamamelis').
enfermedad('Hidropesia','Alcachofa').
enfermedad('Hidropesia','Cardo').
enfermedad('Hidropesia','Perejil').
enfermedad('Hidropesia','Sauco').
enfermedad('Hidropesia','Berros').
enfermedad('Hidropesia','Retama').
enfermedad('Hidropesia','Alcachofa').
enfermedad('Higado congestionado','Marrubio').
enfermedad('Higado congestionado','Boldo').
enfermedad('Higado congestionado','Doradilla').
enfermedad('Higado congestionado','Ruibarbo').
enfermedad('Higado con colicos','Manzanilla').
enfermedad('Higado con bilis','Lechuga').
enfermedad('Higado con bilis','Tila').
enfermedad('Higado con letericia','Papaploquelite').
enfermedad('Higado con letericia','Achicoria').
enfermedad('Higado con letericia','Berros').
enfermedad('Higado con letericia','Llanten').
enfermedad('Higado con letericia','Retama').
enfermedad('Higado con letericia','Tecomasuchil').
enfermedad('Hipertension alta','Ajo').
enfermedad('Hipertension alta','Esparrago').
enfermedad('Hipertension alta','Alpiste').
enfermedad('Hipertension alta','Murdago').
enfermedad('Hipertension baja','Miel').
enfermedad('Hipertension baja','Nuez de kola').
enfermedad('Hipertension baja','Crategus').
enfermedad('Hipertension baja','Acedera').
enfermedad('Hipo','Anis').
enfermedad('Hipo','Hinojo').
enfermedad('Hipo','Tila').
enfermedad('Hipo','Valleriana').
enfermedad('Hiterismo','Azahar').
enfermedad('Hiterismo','Beleño').
enfermedad('Hiterismo','Gelsemio').
enfermedad('Hiterismo','Tila').
enfermedad('Hiterismo','Valeriana').
enfermedad('Insomnio','Pasiflora').
enfermedad('Insomnio','Azahar').
enfermedad('Insomnio','Menta').
enfermedad('Insomnio','Manzanilla').
enfermedad('Insomnio','Lechuga').
enfermedad('Insomnio','Tila').
enfermedad('Intestino','Genciana').
enfermedad('Intestino','Melisa').
enfermedad('Impotencia sexual','Yohimbo').
enfermedad('Impotencia sexual','Damiana').
enfermedad('Impotencia sexual','Nuez vomica').
enfermedad('Impotencia sexual','Aguacate').
enfermedad('Jaqueca','Manzanilla').
enfermedad('Jaqueca','Acanto').
enfermedad('Jaqueca','Valeriana').
enfermedad('Jaqueca','Tila').
enfermedad('Jaqueca','Chicalote').
enfermedad('Lactancia','Hinojo').
enfermedad('Lactancia','Anis').
enfermedad('Lactancia','Menta').
enfermedad('Lactancia','Perejil').
enfermedad('Lactancia','Zanahoria').
enfermedad('Laringitis','Aconito').
enfermedad('Laringitis','Borraja').
enfermedad('Laringitis','Cebolla').
enfermedad('Laringitis','Rosa').
enfermedad('Laringitis','Benjuilencino').
enfermedad('Leucorrea','Encina').
enfermedad('Leucorrea','Zarzaparrilla').
enfermedad('Leucorrea','Pino').
enfermedad('Leucorrea','Enebro').
enfermedad('Leucorrea','Genciana').
enfermedad('Lombrices','Ajenjo').
enfermedad('Lombrices','Ajo').
enfermedad('Lombrices','Cebolla').
enfermedad('Lombrices','Brionia').
enfermedad('Lombrices','Aguacate').
enfermedad('Lombrices','Papaya').
enfermedad('Lombrices','Epazote').
enfermedad('Lumbago','Avena').
enfermedad('Lumbago','Cebada').
enfermedad('Lumbago','Tomillo').
enfermedad('Lumbago','Vergena').
enfermedad('Llagas','Fenogreco').
enfermedad('Llagas','Eucalipto').
enfermedad('Llagas','Llanton').
enfermedad('Llagas','Sanguinaria').
enfermedad('Malaria','Quina').
enfermedad('Malaria','Girasol').
enfermedad('Malaria','Eucalipto').
enfermedad('Malaria','Cardo').
enfermedad('Menopausia','Azahax').
enfermedad('Menopausia','Hamemelis').
enfermedad('Menopausia','Tila').
enfermedad('Menopausia','Quina roja').
enfermedad('Menstuacion abundante','Azafran').
enfermedad('Menstuacion abundante','Hamamelis').
enfermedad('Menstuacion dolorosa','Belladona').
enfermedad('Menstuacion dolorosa','Anis  Estrella').
enfermedad('Menstuacion escasa','Ruda').
enfermedad('Menstuacion escasa','Ajenjo').
enfermedad('Menstuacion escasa','Mazanilla').
enfermedad('Menstuacion irregular','Apio').
enfermedad('Menstuacion irregular','Hisopo').
enfermedad('Menstuacion irregular','Quina amarilla').
enfermedad('Menstuacion irregular','Sabina').
enfermedad('Menstuacion irregular','Artemisa').
enfermedad('Metorragia (Hemorragia vaginal)','Hamamelis').
enfermedad('Metorragia (Hemorragia vaginal)','Zaopatle').
enfermedad('Metorragia (Hemorragia vaginal)','Perejil').
enfermedad('Metorragia (Hemorragia vaginal)','Cuexnecillo centeno').
enfermedad('Dolor de muelas','Clavo').
enfermedad('Dolor de muelas','Hiedra').
enfermedad('Hemorragias nasales','Ortiga').
enfermedad('Hemorragias nasales','Cola de caballo').
enfermedad('Hemorragias nasales','Ruda').
enfermedad('Hemorragias nasales','Eucalipto').
enfermedad('Nauseas','Anis').
enfermedad('Nauseas','Ajenjo').
enfermedad('Nauseas','Menta').
enfermedad('Nauseas','Salvia').
enfermedad('Neuralgias','Manzanilla').
enfermedad('Neuralgias','Menta').
enfermedad('Neuralgias','Valeriana').
enfermedad('Neuralgias','Boldo').
enfermedad('Neurastenia','Pasiflora').
enfermedad('Neurastenia','Te negro').
enfermedad('Neurastenia','Mate').
enfermedad('Neurastenia','Valeriana').
enfermedad('Nefritis(Inflamacion de los riñones)','Linaza').
enfermedad('Nefritis(Inflamacion de los riñones)','Grama').
enfermedad('Nefritis(Inflamacion de los riñones)','Cebada').
enfermedad('Nefritis(Inflamacion de los riñones)','Llanten').
enfermedad('Nefritis(Inflamacion de los riñones)','Doradilla').
enfermedad('Nefritis(Inflamacion de los riñones)','Esparrago').
enfermedad('Nefritis(Inflamacion de los riñones)','Ruda').
enfermedad('Obesidad','Toronjil').
enfermedad('Obesidad','Marrubio').
enfermedad('Obesidad','Limon').
enfermedad('Obesidad','Malva').
enfermedad('Obesidad','Esparragos').
enfermedad('Oidos','Boldo').
enfermedad('Oidos','Aceite de oliva').
enfermedad('Oidos','Llanten').
enfermedad('Oidos','Hiedra').
enfermedad('Ojos (Conjuntivitis, irritacion)','Manzanilla').
enfermedad('Ojos (Conjuntivitis, irritacion)','Limon').
enfermedad('Ojos (Conjuntivitis, irritacion)','Hanten').
enfermedad('Ojos (Conjuntivitis, irritacion)','Salvia').
enfermedad('Ojos (Conjuntivitis, irritacion)','Ruda').
enfermedad('Ojos (Conjuntivitis, irritacion)','Rosal').
enfermedad('Paludismo','Ajenjo').
enfermedad('Paludismo','Quina').
enfermedad('Pecas','Berro').
enfermedad('Pecas','Genciana').
enfermedad('Pecas','Rabano').
enfermedad('Pecas','Papaya').
enfermedad('Pies olorosos','Laurel').
enfermedad('Pies olorosos','Encina').
enfermedad('Piquetes de abeja','Miel').
enfermedad('Piquetes de abeja','Perejil').
enfermedad('Piquetes de abeja','Cebolla').
enfermedad('Piquetes de abeja','Puerro').
enfermedad('Piquetes de araña','Fresno').
enfermedad('Piquetes de araña','Ipecacuana').
enfermedad('Piquetes de mosco','Alcanfor'). 
enfermedad('Piquetes de mosco','Perejil').
enfermedad('Piquetes de mosco','Amamelis').
enfermedad('Piquetes de bibora','Anagalida').
enfermedad('Pleurecia','Jengibre').    
enfermedad('Pleurecia','Linaza').
enfermedad('Pleurecia','Cardo').
enfermedad('Pleurecia','Girasol').
enfermedad('Piorrea','Ipecacuana').   
enfermedad('Prostata','Cola de caballo').
enfermedad('Pulmonia','Eucalipto').
enfermedad('Pulmonia','Ocote').    
enfermedad('Pulmonia','Gordolobo').     
enfermedad('Pulmonia','Borraja').
enfermedad('Pulmonia','Sauco').
enfermedad('Quemaduras','Linaza Cataplasma').
enfermedad('Quemaduras','Cebolla').
enfermedad('Quemaduras','Hiedra').
enfermedad('Quemaduras','Gordolobo').
enfermedad('Raquitismo','Nogal').
enfermedad('Reumatismo','Ajo').
enfermedad('Reumatismo','Apio').
enfermedad('Reumatismo','Borraja').
enfermedad('Reumatismo','Gobernadora').
enfermedad('Reumatismo','Pino').
enfermedad('Reumatismo','Romero').
enfermedad('Reumatismo','Sanguinaria').
enfermedad('Reumatismo','Maxrubio').
enfermedad('Reumatismo','Tabaco').
enfermedad('Riñones','Cabellos de elote').
enfermedad('Riñones','Cola de caballo').
enfermedad('Riñones','Apio').
enfermedad('Ronquera','Eucalipto').
enfermedad('Ronquera','Pino').
enfermedad('Ronquera','Gordolobo').
enfermedad('Sabañones','Ajo').
enfermedad('Sabañones','Cebolla').
enfermedad('San vito (Mal de)','Estafiate').
enfermedad('San vito (Mal de)','Valeriana').
enfermedad('Sarampion','Borraja').
enfermedad('Sarampion','Ortiga').
enfermedad('Sarampion','Sauco').
enfermedad('Sarna','Ajo').
enfermedad('Sarna','Alcanfor').
enfermedad('Sarna','Menta').
enfermedad('Sarna','Tomillo').
enfermedad('Sarna','Romero').
enfermedad('Sarpullido','Encina').
enfermedad('Sarpullido','Salvia').
enfermedad('Sarpullido','Tila').
enfermedad('Sed','Limon').
enfermedad('Sed','Tamarindo').
enfermedad('Sed','Pirul').
enfermedad('Solitaria','Semilla de calabaza').
enfermedad('Solitaria','Granado').
enfermedad('Solitaria','Coquito de aceite').
enfermedad('Solitaria','Helecho macho').
enfermedad('Sudoracion excesiva','Encina').
enfermedad('Tifoidea','Alcanfor').
enfermedad('Tifoidea','Borraja').
enfermedad('Tifoidea','Quina').
enfermedad('Tifoidea','Canela').
enfermedad('Tifoidea','Romero').
enfermedad('Tifoidea','Salvia').
enfermedad('Tiña','Berro').
enfermedad('Tiña','Tila').
enfermedad('Tiña','Tamarindo').
enfermedad('Tiña','Salvia').
enfermedad('Tos','Eucalipto').
enfermedad('Tos','Capulin').
enfermedad('Tos','Cedron').
enfermedad('Tos','Salvia').
enfermedad('Tos','Malva').
enfermedad('Tos','Marrubio').
enfermedad('Tos Ferina','Gelsemio').
enfermedad('Tos Ferina','Quina').
enfermedad('Tos Ferina','Rabano').
enfermedad('Tos Ferina','Violeta').
enfermedad('Tuberculosis','Jugo de vastago de platano morado').
enfermedad('Tuberculosis','Mastuerso').
enfermedad('Tuberculosis','Berro').
enfermedad('Tuberculosis','Ajo').
enfermedad('Tuberculosis','Eucalipto').
enfermedad('Tuberculosis','Pirul').
enfermedad('Tuberculosis','Pino').
enfermedad('Tuberculosis','Roble').
enfermedad('Ulcera','Cuachalalate').
enfermedad('Ulcera','Sanguinaria').
enfermedad('Ulcera','Cola de caballo').
enfermedad('Ulcera','Girasol').
enfermedad('Urticaria','Limon').
enfermedad('Urticaria','Ruibarbo').
enfermedad('Varices','Hamamelis').
enfermedad('Varices','Castaño de indias').
enfermedad('Varices','Toronjil').
enfermedad('Varices','Llanten').
enfermedad('Vejiga','Apio').
enfermedad('Vejiga','Cipres').
enfermedad('Vejiga','Cola de caballo').
enfermedad('Vejiga','Malva').
enfermedad('Vejiga','Ortiga').
enfermedad('Verrugas','Leche de higuera').
enfermedad('Verrugas','Cebolla').
enfermedad('Verrugas','Nogal').
enfermedad('Vertigos','Albahaca').
enfermedad('Vertigos','Espino').
enfermedad('Vomitos','Menta').
enfermedad('Vomitos','Tila').
enfermedad('Vomitos','Marrubio').
enfermedad('Vomitos','Valeriana').
enfermedad('Vomitos','Salvia').
enfermedad('Voz','Cilantro').
enfermedad('Voz','Ajo').
enfermedad('Voz','Limon').
enfermedad('Voz','Pino').
iman('Digitaria','C:/Interfaz_Yerberito/YERBERITO/plantas/digitaria.jpg').
iman('Opio','C:/Interfaz_Yerberito/YERBERITO/plantas/opio.jpg').
iman('Ipeca','C:/Interfaz_Yerberito/YERBERITO/plantas/ipeca.jpg').
iman('Nuez vomica','C:/Interfaz_Yerberito/YERBERITO/plantas/nuez_vomica.jpg').
iman('Eleboro blanco','C:/Interfaz_Yerberito/YERBERITO/plantas/eleboro_blanco.jpg').
iman('Colchico','C:/Interfaz_Yerberito/YERBERITO/plantas/colchico.jpg').
iman('Belladona','C:/Interfaz_Yerberito/YERBERITO/plantas/belladona.jpg').
iman('Quina','C:/Interfaz_Yerberito/YERBERITO/plantas/quina.jpg').
iman('Cacao','C:/Interfaz_Yerberito/YERBERITO/plantas/cacao.jpg').
iman('Retama','C:/Interfaz_Yerberito/YERBERITO/plantas/retama.jpg').
iman('Coca','C:/Interfaz_Yerberito/YERBERITO/plantas/coca.jpg').
iman('Peyote','C:/Interfaz_Yerberito/YERBERITO/plantas/peyote.jpg').
iman('Efedra','C:/Interfaz_Yerberito/YERBERITO/plantas/efedra.jpg').
iman('Barbasco','C:/Interfaz_Yerberito/YERBERITO/plantas/barbasco.jpg').
iman('Nenufar amarillo','C:/Interfaz_Yerberito/YERBERITO/plantas/nenufar.jpg').
iman('Name','C:/Interfaz_Yerberito/YERBERITO/plantas/Name.jpg').
iman('Artemisa ','C:/Interfaz_Yerberito/YERBERITO/plantas/artemisa.jpg').
iman('Semilla de yute','C:/Interfaz_Yerberito/YERBERITO/plantas/semilla de yute.jpg').
iman('Toloache','C:/Interfaz_Yerberito/YERBERITO/plantas/toloache.jpg').
iman('Eucalipto','C:/Interfaz_Yerberito/YERBERITO/plantas/eucalipto.jpg').
iman('Rosal','C:/Interfaz_Yerberito/YERBERITO/plantas/rosal.jpg').
iman('Abrojo','C:/Interfaz_Yerberito/YERBERITO/plantas/abrojo.jpg').
iman('Acacia','C:/Interfaz_Yerberito/YERBERITO/plantas/acacia.jpg').
iman('Acanto','C:/Interfaz_Yerberito/YERBERITO/plantas/acanto.jpg').
iman('Aceitilla','C:/Interfaz_Yerberito/YERBERITO/plantas/aceitilla.jpg').
iman('Achicoria','C:/Interfaz_Yerberito/YERBERITO/plantas/achicoria.jpg').
iman('Diente de leon','C:/Interfaz_Yerberito/YERBERITO/plantas/diente de leon.jpg').
iman('Doradilla','C:/Interfaz_Yerberito/YERBERITO/plantas/doradilla.jpg').
iman('Ricino','C:/Interfaz_Yerberito/YERBERITO/plantas/ricino.jpg').
iman('Romero','C:/Interfaz_Yerberito/YERBERITO/plantas/romero.jpg').
iman('Sauce','C:/Interfaz_Yerberito/YERBERITO/plantas/sauce.jpg').
iman('Amapola','C:/Interfaz_Yerberito/YERBERITO/plantas/amapola.jpg').
iman('Manzanilla','C:/Interfaz_Yerberito/YERBERITO/plantas/manzanilla.jpg').
%Tipo de planta
tipo('Digitaria','Tonica').
tipo('Opio','').
tipo('Ipeca ','Hemostatica').
tipo('Ipeca ','Hepatica').
tipo('Nuez vomica ','Emetica').
tipo('Nuez vomica ','Febrifuga').
tipo('Eleboro blanco','hipotensor').
tipo('Colchico  ','Toxica').
tipo('Belladona','Oftalmologica').
tipo('Belladona','Toxica').
tipo('Quina','Febrifuga').
tipo('Quina','Tonica').
tipo('Cacao','Diuretica').
tipo('Retama','Tonica').
tipo('Retama','Purgante').
tipo('Retama','Diuretica').
tipo('Retama','Depurativa').
tipo('Coca','').
tipo('Peyote','').
tipo('Efedra','Oftalmologica').
tipo('Barbasco','').
tipo('Nenufar amarillo','Antibiotica').
tipo('Ñame','').
tipo('Artemisa','').
tipo('Semilla de yute ','Glucosido').
tipo('Toloache','Toxica').
tipo('Toloache','Anestesica').
tipo('Eucalipto','Antibiotica').
tipo('Rosal','Laxante').
tipo('Rosal','Astringente').
tipo('Abrojo','Diuretica').
tipo('Acacia','Analgesica').
tipo('Acanto','Aperitivo').
tipo('Acanto','Antivenenoso').
tipo('Acanto','Emoliente').
tipo('Aceitilla','Tonica').
tipo('Achicoria','Diuretica').
tipo('Achicoria','Depurativa').
tipo('Diente de leon','Aperitva').
tipo('Diente de leon','Depurativa').
tipo('Diente de leon','Laxante').
tipo('Diente de leon','Colagoga').
tipo('Diente de leon','Diuretica').
tipo('Doradilla','Diuretica').
tipo('Doradilla','Colagoga').
tipo('Doradilla','Refrescante').
tipo('Ricino','Purgante').
tipo('Romero','Estimulante').
tipo('Romero','Emenagogo').
tipo('Romero','Estomacal').
tipo('Sauce','').
tipo('Amapola','').
tipo('Manzanilla','Tonica').
tipo('Manzanilla','Emenagogo').
tipo('Manzanilla','Carminativo').
tipo('Manzanilla','Estomacal').