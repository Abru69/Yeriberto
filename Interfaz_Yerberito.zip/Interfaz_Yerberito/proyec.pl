 :- use module(library(pce)).
mostrar(V,D,M):- new(I, image(V)),
        new(B, bitmap(I)),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1),
        send(D1,below(M)).




:- pce global(@name prompter, make name prompter).

        make name prompter(P) :-
                new(P, dialog),
                send(P, kind, transient),
                send(P, append, label(prompt)),
                send(P, append,
                        new(TI, text item(name, '',
                                 message(P?ok member, execute)))),
                send(P, append, button(ok, message(P, return, TI?selection))),
                %%send(P, append, button(ok, message(@prolog,pp))),
                send(P, append, button(cancel, message(P, return, @nil))).


        ask name(Prompt, Label, Name) :-
                send(@name prompter?prompt member, selection, Prompt),
                send(@name prompter?name member, label, Label),
                send(@name prompter?name member, clear),
                get(@name prompter, confirm centered, RawName),
                send(@name prompter, show, @off),
                RawName \== @nil,
                Name = RawName.

        ask name :-
                ask name('Plantas medicinales','General',General),
                pp(General).
       ask name1:-
                  ask name('Relacion por:','Curacion',Curacion),
                  pp1(Curacion).

        ask name2:-
                  ask name('Planta','General:',General),
                  pp(General).
        ask name3:-
                  ask name('Relacion por: ','Tipo de planta:',Tipo de planta),
                  pp3(Tipo de planta).



start :-
        new(D,dialog('Busqueda de plantas medicinales')),
        send(D,size,size(660,400)),
        send(D,colour,colour(red)),
        send(D, append, new(Menu, menu bar)),
        send(Menu, append, new(Iniciar, popup(iniciar))),
        send(Menu,append,new(Iniciar1,popup('Relacion por: '))),
        send list(Iniciar, append,
                         [ menu item(iniciar, message(@prolog,ask name))
                         ]),
        send list(Iniciar1,append,
                      [menu item(general,message(@prolog,ask name1))
                      ]),
               send list(Iniciar1,append,
                      [menu item(curacion,message(@prolog,ask name3))
                      ]),
               send list(Iniciar1,append,
                      [menu item('Tipo de planta',message(@prolog,ask name4))
                      ]),

        mostrar('C:/Interfaz Yerberito/YERBERITO/yerberito.jpg',D,Menu),
        send(D,open,point(0,0)),
         consult('proyec.pl'),
           nl.








pp(General):-
        new(D,dialog(General)),
        send(D,size,size(660,500)),
        send(D,colour,colour(black)),
        send(D, append, new(Menu, menu bar)),
        send(D, display, text(General, center, normal), point(320,5)),

        raza(General,Nombre),
        send(D, display, text('Su nombre cientifico es: ', center, normal), point(320,20)),
	nl,
        send(D, display, text(Nombre, center, normal), point(440,20)),

        derrotado(General,Curacion),
	send(D, display, text('Alivia:', center, normal), point(320,40)),
	nl,
        send(D, display, text(Curacion, center
        , normal), point(440,40)),

        tecnica(General,Tipo de planta),
	send(D, display, text('La planta es:', center, normal), point(320,60)),nl,
	nl,
        send(D, display, text(Tipo de planta, center, normal), point(440,60)),

         familiar(General,Elementos),
	send(D, display, text('Contiene elementos como:', center, normal), point(320,80)),nl,
	nl,
        send(D, display, text(Elementos, center, normal), point(440,80)),



	iman(General,Foto)  ,
        mostrar(Foto,D,Menu),
        send(D,open,point(200,200)),
         nl.
--------------------
pp1(Curacion):-
        new(D,dialog(Curacion)),
        send(D,size,size(560,400)),
        send(D,colour,colour(black)),
        send(D, append, new(Menu, menu bar)),
        send(D, display, text(Curacion, center, normal), point(320,5)),

        general(Curaciones,Curacion),
        elementos(Curaciones,Elementos),
        send(D, display, text('Alivia: ', center, normal), point(320,20)),
        send(D, display, text(Curaciones, center, normal), point(440,20)),
        send(D, display, text('Contiene elementos como: ', center, normal), point(320,40)),
        send(D, display, text(Elementos, center, normal), point(440,40)),


        send(Menu,append,new(Iniciar2,popup('Buscar: '))),
               send list(Iniciar2,append,
                      [menu item(Curaciones,message(@prolog,ask name2))
                      ]),

         iman(Curacion,Foto)  ,
        mostrar(Foto,D,Menu),
        send(D,open,point(200,200)),
        nl.

pp3(Tipo de planta):-
        new(D,dialog(Tipo de planta)),
        send(D,size,size(560,400)),
        send(D,colour,colour(black)),
        send(D, append, new(Menu, menu bar)),
        send(D, display, text(Tipo de planta, center, normal), point(320,5)),
        tipo de planta(Tipo, Tipo de planta),
        nombre(Planta, Nombre),
        send(D, display, text('Planta: ', center, normal), point(320,20)),
        send(D, display, text(Planta, center, normal), point(420,20)),
        send(D, display, text('Contiene elementos como: ', center, normal), point(320,40)),
        send(D, display, text(Elementos, center, normal), point(420,40)),


        send(Menu,append,new(Iniciar2,popup('Buscar: '))),
               send list(Iniciar2,append,
                      [menu item(planta,message(@prolog,ask name2))
                      ]),
                iman(Tipo de planta,Foto)  ,
        mostrar(Foto,D,Menu),
        send(D,open,point(200,200)),
        nl.


%nombre_cientifico_planta

nombre('Digitaria','digitalis purpura').
nombre('Opio','').
nombre('Ipeca ','').
nombre('Nuez vomica ','Strychnos nux vomica').
nombre('Eleboro blanco','').
nombre('Colchico  ','colchicum autumn').
nombre('Belladona','atropa belladona').
nombre('Quina','chinchona calisaya').
nombre('Cacao','').
nombre('Retama','spastium junoevm').
nombre('Coca','').
nombre('Peyote','').
nombre('Efedra','').
nombre('Barbasco','Diodcorea mexicana').
nombre('Nenufar amarillo','animal').
nombre('Ñame','').
nombre('Artemisa','').
nombre('Semilla de yute ','').
nombre('Toloache','datura stramonium').
nombre('Eucalipto','eucaliptus globolus').
nombre('Rosal','rosa centifola').
nombre('Abrojo','tribulus cistoides').
nombre('Acacia','').
nombre('Acanto','acanthus mollis').
nombre('Aceitilla','bidens leucantha').
nombre('Achicoria','chicorium intybus').
nombre('Diente de leon','taraxacum officinale').
nombre('Doradilla','selaginella rupestris').
nombre('Ricino','ricinus communis').
nombre('Romero','rosmarinus off').
nombre('Sauce','').
nombre('Amapola','').
nombre('Manzanilla','matricaria chamomilla').

%lista_imagenes.

iman('Digitaria','C:/Interfaz Yerberito/YERBERITO/medicamentos/digital corazon.jpg').
iman('Opio','C:/Interfaz Yerberito/YERBERITO/medicamentos/opio.jpg').
iman('Ipeca','C:/Interfaz Yerberito/YERBERITO/medicamentos/ipeca.jpg').
iman('Nuez vomica','C:/Interfaz Yerberito/YERBERITO/medicamentos/nuez vomica.jpg').
iman('Eleboro blanco ','C:/Interfaz Yerberito/YERBERITO/medicamentos/eleboro blanco.jpg').
iman('Colchico ','C:/Interfaz Yerberito/YERBERITO/medicamentos/colchico.jpg').
iman('Belladona ','C:/Interfaz Yerberito/YERBERITO/medicamentos/belladona.jpg').
iman('Quina ','C:/Interfaz Yerberito/YERBERITO/medicamentos/quina.jpg').
iman('Cacao','C:/Interfaz Yerberito/YERBERITO/medicamentos/cacao.jpg').
iman('Retama ','C:/Interfaz Yerberito/YERBERITO/medicamentos/retama.jpg').
iman('Coca ','C:/Interfaz Yerberito/YERBERITO/medicamentos/coca.jpg').
iman('Peyote','C:/Interfaz Yerberito/YERBERITO/medicamentos/peyote.jpg').
iman('Efedra','C:/Interfaz Yerberito/YERBERITO/medicamentos/efedra.jpg').
iman('Barbasco','C:/Interfaz Yerberito/YERBERITO/medicamentos/barbasco.jpg').
iman('Nenufar amarillo','C:/Interfaz Yerberito/YERBERITO/medicamentos/nenúfar amarillo.jpg').
iman('Ñame','C:/Interfaz Yerberito/YERBERITO/medicamentos/ñame.jpg').
iman('Artemisa ','C:/Interfaz Yerberito/YERBERITO/medicamentos/artemisa.jpg').
iman('Semilla de yute ','C:/Interfaz Yerberito/YERBERITO/medicamentos/semilla de yute.jpg').
iman('Toloache ','C:/Interfaz Yerberito/YERBERITO/medicamentos/toloache.jpg').
iman('Eucalipto ','C:/Interfaz Yerberito/YERBERITO/medicamentos/eucalipto.jpg').
iman('Rosal  ','C:/Interfaz Yerberito/YERBERITO/medicamentos/rosal.jpg').
iman('Abrojo','C:/Interfaz Yerberito/YERBERITO/abrojo.jpg').
iman('Acacia','C:/Interfaz Yerberito/YERBERITO/acacia.jpg').
iman('Acanto','C:/Interfaz Yerberito/YERBERITO/acanto.jpg').
iman('Aceitilla','C:/Interfaz Yerberito/YERBERITO/aceitilla.jpg').
iman('Achicoria','C:/Interfaz Yerberito/YERBERITO/achicoria.jpg').
iman('Diente de leon','C:/Interfaz Yerberito/YERBERITO/diente de leon.jpg').
iman('Doradilla','C:/Interfaz Yerberito/YERBERITO/doradilla.jpg').
iman('Ricino','C:/Interfaz Yerberito/YERBERITO/ricino.jpg').
iman('Romero','C:/Interfaz Yerberito/YERBERITO/romero.jpg').
iman('Sauce','C:/Interfaz Yerberito/YERBERITO/sauce.jpg').
iman('Amapola','C:/Interfaz Yerberito/YERBERITO/amapola.jpg').
iman('Manzanilla','C:/Interfaz Yerberito/YERBERITO/manzanilla.jpg').

%contiene.
contiene('Digitaria','vitaminas').
contiene('Digitaria','hormonas').
contiene('Digitaria','minerales').
contiene('Digitaria','metaloides').
contiene('Digitaria','proteinas').
contiene('Digitaria','oligoelemntos').
contiene('Digitaria','enzimas').
contiene('Digitaria','alcaloides').
contiene('Opio','vitaminas').
contiene('Opio','hormonas').
contiene('Opio','minerales').
contiene('Opio','metaloides').
contiene('Opio','proteinas').
contiene('Opio','oligoelemntos').
contiene('Opio','enzimas').
contiene('Opio','alcaloides').
contiene('Ipeca','vitaminas').
contiene('Ipeca','hormonas').
contiene('Ipeca','minerales').
contiene('Ipeca','metaloides').
contiene('Ipeca','proteinas').
contiene('Ipeca','oligoelemntos').
contiene('Ipeca','enzimas').
contiene('Ipeca','alcaloides').
contiene('Nuez vomica','vitaminas').
contiene('Nuez  vomica','hormonas').
contiene('Nuez  vomica','minerales').
contiene('Nuez  vomica','metaloides').
contiene('Nuez  vomica','proteinas').
contiene('Nuez  vomica','oligoelemntos').
contiene('Nuez  vomica','enzimas').
contiene('Nuez  vomica','alcaloides').
contiene('Eleboro blanco','vitaminas').
contiene('Eleboro blanco','hormonas').
contiene('Eleboro blanco','minerales').
contiene('Eleboro blanco','metaloides').
contiene('Eleboro blanco','proteinas').
contiene('Eleboro blanco','oligoelemntos').
contiene('Eleboro blanco','enzimas').
contiene('Eleboro blanco','alcaloides').
contiene('Colchico','vitaminas').
contiene('Colchico','hormonas').
contiene('Colchico','minerales').
contiene('Colchico','metaloides').
contiene('Colchico','proteinas').
contiene('Colchico','oligoelemntos').
contiene('Colchico','enzimas').
contiene('Colchico','alcaloides').
contiene('Belladona','vitaminas').
contiene('Belladona','hormonas').
contiene('Belladona','minerales').
contiene('Belladona','metaloides').
contiene('Belladona','proteinas').
contiene('Belladona','oligoelemntos').
contiene('Belladona','enzimas').
contiene('Belladona','alcaloides').
contiene('Quina','vitaminas').
contiene('Quina','hormonas').
contiene('Quina','minerales').
contiene('Quina','metaloides').
contiene('Quina','proteinas').
contiene('Quina','oligoelemntos').
contiene('Quina','enzimas').
contiene('Quina','alcaloides').
contiene('Cacao','vitaminas').
contiene('Cacao','hormonas').
contiene('Cacao','minerales').
contiene('Cacao','metaloides').
contiene('Cacao','proteinas').
contiene('Cacao','oligoelemntos').
contiene('Cacao','enzimas').
contiene('Cacao','alcaloides').
contiene('Retama','vitaminas').
contiene('Retama','hormonas').
contiene('Retama','minerales').
contiene('Retama','metaloides').
contiene('Retama','proteinas').
contiene('Retama','oligoelemntos').
contiene('Retama','enzimas').
contiene('Retama','alcaloides').
contiene('Coca','vitaminas').
contiene('Coca','hormonas').
contiene('Coca','minerales').
contiene('Coca','metaloides').
contiene('Coca','proteinas').
contiene('Coca','oligoelemntos').
contiene('Coca','enzimas').
contiene('Coca','alcaloides').
contiene('Peyote','vitaminas').
contiene('Peyote','hormonas').
contiene('Peyote','minerales').
contiene('Peyote','metaloides').
contiene('Peyote','proteinas').
contiene('Peyote','oligoelemntos').
contiene('Peyote','enzimas').
contiene('Peyote','alcaloides').
contiene('Efedra','vitaminas').
contiene('Efedra','hormonas').
contiene('Efedra','minerales').
contiene('Efedra','metaloides').
contiene('Efedra','proteinas').
contiene('Efedra','oligoelemntos').
contiene('Efedra','enzimas').
contiene('Efedra','alcaloides').
contiene('Barbasco','vitaminas').
contiene('Barbasco','hormonas').
contiene('Barbasco','minerales').
contiene('Barbasco','metaloides').
contiene('Barbasco','proteinas').
contiene('Barbasco','oligoelemntos').
contiene('Barbasco','enzimas').
contiene('Barbasco','alcaloides').
contiene('Nenufar amarillo','vitaminas').
contiene('Nenufar amarillo','hormonas').
contiene('Nenufar amarillo','minerales').
contiene('Nenufar amarillo','metaloides').
contiene('Nenufar amarillo','proteinas').
contiene('Nenufar amarillo','oligoelemntos').
contiene('Nenufar amarillo','enzimas').
contiene('Nenufar amarillo','alcaloides').
contiene('Ñame','vitaminas').
contiene('Ñame','hormonas').
contiene('Ñame','minerales').
contiene('Ñame','metaloides').
contiene('Ñame','proteinas').
contiene('Ñame','oligoelemntos').
contiene('Ñame','enzimas').
contiene('Ñame','alcaloides').
contiene('Artemisa','vitaminas').
contiene('Artemisa','hormonas').
contiene('Artemisa','minerales').
contiene('Artemisa','metaloides').
contiene('Artemisa','proteinas').
contiene('Artemisa','oligoelemntos').
contiene('Artemisa','enzimas').
contiene('Artemisa','alcaloides').
contiene('Semilla de yute','vitaminas').
contiene('Semilla de yute','hormonas').
contiene('Semilla de yute','minerales').
contiene('Semilla de yute','metaloides').
contiene('Semilla de yute','proteinas').
contiene('Semilla de yute','oligoelemntos').
contiene('Semilla de yute','enzimas').
contiene('Semilla de yute','alcaloides').
contiene('Toloache','vitaminas').
contiene('Toloache','hormonas').
contiene('Toloache','minerales').
contiene('Toloache','metaloides').
contiene('Toloache','proteinas').
contiene('Toloache','oligoelemntos').
contiene('Toloache','enzimas').
contiene('Toloache','alcaloides').
contiene('Eucalipto','vitaminas').
contiene('Eucalipto','hormonas').
contiene('Eucalipto','minerales').
contiene('Eucalipto','metaloides').
contiene('Eucalipto','proteinas').
contiene('Eucalipto','oligoelemntos').
contiene('Eucalipto','enzimas').
contiene('Eucalipto','alcaloides').
contiene('Rosal','vitaminas').
contiene('Rosal','hormonas').
contiene('Rosal','minerales').
contiene('Rosal','metaloides').
contiene('Rosal','proteinas').
contiene('Rosal','oligoelemntos').
contiene('Rosal','enzimas').
contiene('Rosal','alcaloides').
contiene('Abrojo','vitaminas').
contiene('Abrojo','hormonas').
contiene('Abrojo','minerales').
contiene('Abrojo','metaloides').
contiene('Abrojo','proteinas').
contiene('Abrojo','oligoelemntos').
contiene('Abrojo','enzimas').
contiene('Abrojo','alcaloides').
contiene('Acacia','vitaminas').
contiene('Acacia','hormonas').
contiene('Acacia','minerales').
contiene('Acacia','metaloides').
contiene('Acacia','proteinas').
contiene('Acacia','oligoelemntos').
contiene('Acacia','enzimas').
contiene('Acacia','alcaloides').
contiene('Acanto','vitaminas').
contiene('Acanto','hormonas').
contiene('Acanto','minerales').
contiene('Acanto','metaloides').
contiene('Acanto','proteinas').
contiene('Acanto','oligoelemntos').
contiene('Acanto','enzimas').
contiene('Acanto','alcaloides').
contiene('Aceitilla','vitaminas').
contiene('Aceitilla','hormonas').
contiene('Aceitilla','minerales').
contiene('Aceitilla','metaloides').
contiene('Aceitilla','proteinas').
contiene('Aceitilla','oligoelemntos').
contiene('Aceitilla','enzimas').
contiene('Aceitilla','alcaloides').
contiene('Achicoria','vitaminas').
contiene('Achicoria','hormonas').
contiene('Achicoria','minerales').
contiene('Achicoria','metaloides').
contiene('Achicoria','proteinas').
contiene('Achicoria','oligoelemntos').
contiene('Achicoria','enzimas').
contiene('Achicoria','alcaloides').
contiene('Diente de leon','alcaloides').
contiene('Doradilla','vitaminas').
contiene('Doradilla','hormonas').
contiene('Doradilla','minerales').
contiene('Doradilla','metaloides').
contiene('Doradilla','proteinas').
contiene('Doradilla','oligoelemntos').
contiene('Doradilla','enzimas').
contiene('Doradilla','alcaloides').
contiene('Ricino','vitaminas').
contiene('Ricino','hormonas').
contiene('Ricino','minerales').
contiene('Ricino','metaloides').
contiene('Ricino','proteinas').
contiene('Ricino','oligoelemntos').
contiene('Ricino','enzimas').
contiene('Ricino','alcaloides').
contiene('Romero','vitaminas').
contiene('Romero','hormonas').
contiene('Romero','minerales').
contiene('Romero','metaloides').
contiene('Romero','proteinas').
contiene('Romero','oligoelemntos').
contiene('Romero','enzimas').
contiene('Romero','alcaloides').
contiene('Sauce','vitaminas').
contiene('Sauce','hormonas').
contiene('Sauce','minerales').
contiene('Sauce','metaloides').
contiene('Sauce','proteinas').
contiene('Sauce','oligoelemntos').
contiene('Sauce','enzimas').
contiene('Sauce','alcaloides').
contiene('Amapola','vitaminas').
contiene('Amapola','hormonas').
contiene('Amapola','minerales').
contiene('Amapola','metaloides').
contiene('Amapola','proteinas').
contiene('Amapola','oligoelemntos').
contiene('Amapola','enzimas').
contiene('Amapola','alcaloides').
contiene('Manzanilla','clorofila').
contiene('Manzanilla','azulina').
contiene('Manzanilla','tanatos').
contiene('Manzanilla','oxalatos').
contiene('Manzanilla','resina').

%Tipo de planta
tipo('Digitaria','Tonica').
tipo('Opio','').
tipo('Ipeca ','Hemostatica').
tipo('Ipeca ','Hepatica').
tipo('Nuez vomica ','Emetica').
tipo('Nuez vomica ','Febrifuga').
tipo('Eleboro blanco','hipotensor').
tipo('Colchico  ','Toxica').
tipo('Belladona','Oftalmologica').
tipo('Belladona','Toxica').
tipo('Quina','Febrifuga').
tipo('Quina','Tonica').
tipo('Cacao','Diuretica').
tipo('Retama','Tonica').
tipo('Retama','Purgante').
tipo('Retama','Diuretica').
tipo('Retama','Depurativa').
tipo('Coca','').
tipo('Peyote','').
tipo('Efedra','Oftalmologica').
tipo('Barbasco','').
tipo('Nenufar amarillo','Antibiotica').
tipo('Ñame','').
tipo('Artemisa','').
tipo('Semilla de yute ','Glucosido').
tipo('Toloache','Toxica').
tipo('Toloache','Anestesica').
tipo('Eucalipto','Antibiotica').
tipo('Rosal','Laxante').
tipo('Rosal','Astringente').
tipo('Abrojo','Diuretica').
tipo('Acacia','Analgesica').
tipo('Acanto','Aperitivo').
tipo('Acanto','Antivenenoso').
tipo('Acanto','Emoliente').
tipo('Aceitilla','Tonica').
tipo('Achicoria','Diuretica').
tipo('Achicoria','Depurativa').
tipo('Diente de leon','Aperitva').
tipo('Diente de leon','Depurativa').
tipo('Diente de leon','Laxante').
tipo('Diente de leon','Colagoga').
tipo('Diente de leon','Diuretica').
tipo('Doradilla','Diuretica').
tipo('Doradilla','Colagoga').
tipo('Doradilla','Refrescante').
tipo('Ricino','Purgante').
tipo('Romero','Estimulante').
tipo('Romero','Emenagogo').
tipo('Romero','Estomacal').
tipo('Sauce','').
tipo('Amapola','').
tipo('Manzanilla','Tonica').
tipo('Manzanilla','Emenagogo').
tipo('Manzanilla','Carminativo').
tipo('Manzanilla','Estomacal').

enfermedad('Absesos','Malva').
enfermedad('Abseso Hepatico','Zarzaparilla').
enfermedad('Acidez Estomacal','Anis').
enfermedad('Acidez Estomacal','Perejil').
enfermedad('Acido Urico','Sanguinaria').
enfermedad('Acido Urico','Limon').
enfermedad('Acido Urico','Sauco').
enfermedad('Acne','Arnica').
enfermedad('Aftas','Llanten').
enfermedad('Aftas','Fenogreco').
enfermedad('Aftas','Zarzamora').
enfermedad('Agotamiento','Salvia').
enfermedad('Agotamiento','Tilo').
enfermedad('Agotamiento','Valeriana').
enfermedad('Agruras','Yerbabuena').
enfermedad('Agruras','Manzanilla').
enfermedad('Agruras','Jugo de limon o toronja').
enfermedad('Albuminaria','Pinguica').
enfermedad('Albuminaria','Quina Roja').
enfermedad('Albuminaria','Encino Rojo').
enfermedad('Alcoholismo','Pimiento').
enfermedad('Almorranas','Salvia').
enfermedad('Almorranas','Hamamelis').
enfermedad('Almorranas','Sanguinaria').
enfermedad('Almorranas','Cola de caballo').
enfermedad('Almorranas','Arnica').
enfermedad('Almorranas','Sauco').
enfermedad('Anemia','Ajenjo').
enfermedad('Anemia','Germen de trigo').
enfermedad('Anemia','Quina').
enfermedad('Anemia','Canela').
enfermedad('Anemia','Alholva').
enfermedad('Anginas','Eucalipto').
enfermedad('Anginas','Cebada').
enfermedad('Anginas','Salvia').
enfermedad('Anginas','Tabachin').
enfermedad('Anginas','Borraja').
enfermedad('Anorexia','Ajenjo').
enfermedad('Anorexia','Genciana').
enfermedad('Anorexia','Yerbabuena').
enfermedad('Arterosclerosis','Limon').
enfermedad('Arterosclerosis','Genciana').
enfermedad('Arterosclerosis','Cardo').
enfermedad('Arterosclerosis','Zarzaparilla').
enfermedad('Arterosclerosis','Arnica').
enfermedad('Arterosclerosis','Cchicalote').
enfermedad('Arterosclerosis','Alcamfor').
enfermedad('Arterosclerosis','Toronja').
enfermedad('Artritis','Limon').
enfermedad('Artritis','Genciana').
enfermedad('Artritis','Cardo').
enfermedad('Artritis','Zarzaparilla').
enfermedad('Artritis','Arnica').
enfermedad('Artritis','Cchicalote').
enfermedad('Artritis','Alcamfor').
enfermedad('Artritis','Toronja').
enfermedad('Asma','Eucalipto').
enfermedad('Asma','Marrubio').
enfermedad('Asma','Toloache').
enfermedad('Asma','Oregano').
enfermedad('Asma','Salvia').
enfermedad('Atonia Estomacal','Lupulu').
enfermedad('Atonia Estomacal','Eucalipto').
enfermedad('Atonia Estomacal','Cuasia').
enfermedad('Bazo','Uva').
enfermedad('Bazo','Cerezo').
enfermedad('Inflamacion de Boca','Malva').
enfermedad('Inflamacion de Boca','Rosal').
enfermedad('Inflamacion de Boca','Limon').
enfermedad('Inflamacion de Boca','Salvia').
enfermedad('Estomatitis de Boca','Rosal').
enfermedad('Estomatitis de Boca','Encina').
enfermedad('Estomatitis de Boca','Salvia').
enfermedad('Estomatitis de Boca','Zarzamora').
enfermedad('Bronquitis','Eucalipto').
enfermedad('Bronquitis','Borraja').
enfermedad('Bronquitis','Anacahuite').
enfermedad('Bronquitis','Gordolobo').
enfermedad('Bronquitis','Tilo').
enfermedad('Bronquitis','Benjui').
enfermedad('Bronquitis','Marrubio').
enfermedad('Bronquitis','Rabano').
enfermedad('Bronconeumonia','Gordolobo').
enfermedad('Bronconeumonia','Eucalipto').
enfermedad('Bronconeumonia','Ipecacuana').
enfermedad('Bronconeumonia','Mostaza').
enfermedad('Caida del cabello','Ortiga').
enfermedad('Caida del cabello','Espinosilla').
enfermedad('Caida del cabello','Marrubio').
enfermedad('Caida del cabello','Romero').
enfermedad('Calambres','Anis').
enfermedad('Calambres','Tila').
enfermedad('Calambres','Manzanilla').
enfermedad('Calambres','Ajenjo').
enfermedad('Calculos biliares','Diente de leon').
enfermedad('Calculos biliares','Aceite de oliva').
enfermedad('Calculos biliares','Retama').
enfermedad('Calculos renales','Cabellos de elote').
enfermedad('Calculos renales','Pinguica').
enfermedad('Calculos renales','Cola de caballo').
enfermedad('Callos','Ajo').
enfermedad('Callos','Cebolla').
enfermedad('Caries','Hiedra').
enfermedad('Caries','Cola de caballo').
enfermedad('Caspa','Ortiga').
enfermedad('Caspa','Limon').
enfermedad('Caspa','Romero').
enfermedad('Cancer de utero','Cuachalalate').
enfermedad('Cancer de utero','Llanten').
enfermedad('Cancer de utero','Siempreviva').
enfermedad('Ciatica','Mastuerzo').
enfermedad('Ciatica','Higuera').
enfermedad('Ciatica','Sauce').
enfermedad('Circulacion','Toronjil').
enfermedad('Circulacion','Sanguinaria').
enfermedad('Circulacion','Salvia').
enfermedad('Circulacion','Hamamelis').
enfermedad('Cistitis','Cola de caballo').
enfermedad('Cistitis','Doradilla').
enfermedad('Cistitis','Ajo').
enfermedad('Cistitis','Cabellos de elote').
enfermedad('Colicos','Menta').
enfermedad('Colicos','Hinojo').
enfermedad('Colicos','Manzanilla').
enfermedad('Colicos','Toronjil').
enfermedad('Colicos','Boldo').
enfermedad('Colitis','Linaza').
enfermedad('Colitis','Anis').
enfermedad('Colitis','Romero').
enfermedad('Colitis','Cola de caballo').
enfermedad('Contusiones','Arnica').
enfermedad('Contusiones','Hamamelis').
enfermedad('Contusiones','Laurel').
enfermedad('Contusiones','Brionia').
enfermedad('Tonico para el Corazon','Digitaria').
enfermedad('Tonico para el Corazon','Salvia').
enfermedad('Tonico para el Corazon','Nuez de kcla').
enfermedad('Tonico para el Corazon','Tejocote').
enfermedad('Depurativos de la sangre','Achicoria').
enfermedad('Depurativos de la sangre','Diente de leon').
enfermedad('Depurativos de la sangre','Apio').
enfermedad('Depurativos de la sangre','Sanguinaria').
enfermedad('Depurativos de la sangre','Zarzaparilla').
enfermedad('Depurativos de la sangre','Berro').
enfermedad('Diabetes','Matarique').
enfermedad('Diabetes','Tronadora').
enfermedad('Diabetes','Eucalipto').
enfermedad('Diabetes','Damiana').
enfermedad('Diarrea cronica','Capulin').
enfermedad('Diarrea cronica','Mezquite').
enfermedad('Diarrea cronica','Tlachichinole').
enfermedad('Diarrea por irritacion','Linaza').
enfermedad('Diarrea por irritacion','Membrillo').
enfermedad('Diarrea por irritacion','Arroz').
enfermedad('Diarrea por irritacion','Cebada').
enfermedad('Diarrea por inflamacion','Guayaba').
enfermedad('Diarrea por inflamacion','Añbahaca').
enfermedad('Diarrea por inflamacion','Granada').
enfermedad('Diarrea verdosa','Manzanilla').
enfermedad('Diarrea verdosa','Simonilla').
enfermedad('Diarrea verdosa','Siempreviva').
enfermedad('Diarrea con sangre','Chaparro amargoso').
enfermedad('Diarrea con sangre','Muicle').
enfermedad('Diarrea con sangre','Monacillo').
enfermedad('Diftera','Limon').
enfermedad('Diftera','Naranja').
enfermedad('Disenteria','Tamarindo').
enfermedad('Disenteria','Chaparro amargoso').
enfermedad('Disenteria','Ipecacuana').
enfermedad('Disenteria','Cedron').
enfermedad('Dispepsia','Anis').
enfermedad('Dispepsia','Menta').
enfermedad('Dispepsia','Yerbabuena').
enfermedad('Dispepsia','Diente').
enfermedad('Dispepsia','Te limon').
enfermedad('Dispepsia','Quina').
enfermedad('Dispepsia','Genciana').
enfermedad('Dispepsia','Tabaquillo').
enfermedad('Dispepsia','Ruibardo').
enfermedad('Dispepsia con dolor','Anis estrella').
enfermedad('Dispepsia con dolor','Valeriana').
enfermedad('Dispepsia con dolor','Manzanilla').
enfermedad('Dolores musculares','Alcanfor').
enfermedad('Empacho','Tamarindo').
enfermedad('Enteritis','Linaza').
enfermedad('Enteritis','Cedron').
enfermedad('Enteritis','Llanten').
enfermedad('Epilepsia','Valeriana').
enfermedad('Epistaxis hemorragia nasal','Hierba de pollo').
enfermedad('Epistaxis hemorragia nasal','Cebolla').
enfermedad('Epistaxis hemorragia nasal','Perejil').
enfermedad('Erisipela','Sauco').
enfermedad('Erisipela','Hiedra').
enfermedad('Erisipela','Zanahoria').
enfermedad('Escarlatina','Borraja').
enfermedad('Escarlatina','Sauco').
enfermedad('Escarlatina','Cebolla').
enfermedad('Escorbuto','Ajo').
enfermedad('Escorbuto','Limon').
enfermedad('Escorbuto','Berro').
enfermedad('Escorbuto','Cebolla').
enfermedad('Escorbuto','Geranio').
enfermedad('Estreñimiento','Ciruela').
enfermedad('Estreñimiento','Linaza').
enfermedad('Estreñimiento','Chia').
enfermedad('Estreñimiento','Tamarindo').
enfermedad('Estreñimiento','Agar-agar').
enfermedad('Faringitis','Eucalipto').
enfermedad('Faringitis','Lavanda').
enfermedad('Faringitis','Anacahuite').
enfermedad('Flatulencias','Apio').
enfermedad('Flatulencias','Tomillo').
enfermedad('Flatulencias','Perejil').
enfermedad('Flatulencias','Anis estrella').
enfermedad('Flatulencias','Hinojo').
enfermedad('Flatulencias','Toronjil').
enfermedad('Flatulencias','Romero').
enfermedad('Flatulencias','Ruibarbo').
enfermedad('Flatulencias','Ruda').
enfermedad('Flatulencias','Menta').
enfermedad('Flebitis','Armica').
enfermedad('Flebitis','Alfalfa').
enfermedad('Flebitis','Lino').
enfermedad('Flebitis','Malvavisco').
enfermedad('Flebitis','Romero').
enfermedad('Flebitis','Quina').
enfermedad('Flemas','Genciana').
enfermedad('Flemas','Oregano').
enfermedad('Forunculos','Fenogreco').
enfermedad('Forunculos','Malvavisco').
enfermedad('Forunculos','Hiedra').
enfermedad('Gastralgia','Manzanilla').
enfermedad('Gastralgia','Anis estrella').
enfermedad('Gonorrea','Cola de caballo').
enfermedad('Gonorrea','Doradilla').
enfermedad('Gonorrea','Zarzaparrilla').
enfermedad('Gota','Apio').
enfermedad('Gota','Cerezo').
enfermedad('Gota','Limon').
enfermedad('Gota','Pino').
enfermedad('Gota','Alcanfor').
enfermedad('Gota','Aconito').
enfermedad('Gota','Belladona').
enfermedad('Gota','Beleño').
enfermedad('Gota','Colchico').
enfermedad('Gota','Chicalote').
enfermedad('Grietas del ano','Encina').
enfermedad('Grietas del pezon','Encina').
enfermedad('Grietas del pezon','Nogal').
enfermedad('Grietas del pezon','Milenrama').
enfermedad('Gripe','Eucalipto').
enfermedad('Gripe','Limon').
enfermedad('Gripe','Quina').
enfermedad('Gripe','Zarzaparrilla').
enfermedad('Gripe','Calendula').
enfermedad('Halitosis','Hinojo').
enfermedad('Halitosis','Menta').
enfermedad('Hemorragia interna','Mastuerzo').
enfermedad('Hemorragia interna','Ortiga').
enfermedad('Hemorragia interna','Rosal').
enfermedad('Hepatitia','Retama').
enfermedad('Hepatitia','Boldo').
enfermedad('Hepatitia','Alcachofa').
enfermedad('Hepatitia','Prodigiosa').
enfermedad('Hepatitia','Cascara sagrada').
enfermedad('Hernia','Helecho').
enfermedad('Hernia','Ricino').
enfermedad('Hernia','Tabaco').
enfermedad('Herpes','Linaza').
enfermedad('Herpes','Llanten').
enfermedad('Herida','Arnica').
enfermedad('Herida','Hamamelis').
enfermedad('Hidropesia','Alcachofa').
enfermedad('Hidropesia','Cardo').
enfermedad('Hidropesia','Perejil').
enfermedad('Hidropesia','Sauco').
enfermedad('Hidropesia','Berros').
enfermedad('Hidropesia','Retama').
enfermedad('Hidropesia','Alcachofa').
enfermedad('Higado congestionado','Marrubio').
enfermedad('Higado congestionado','Boldo').
enfermedad('Higado congestionado','Doradilla').
enfermedad('Higado congestionado','Ruibarbo').
enfermedad('Higado con colicos','Manzanilla').
enfermedad('Higado con bilis','Lechuga').
enfermedad('Higado con bilis','Tila').
enfermedad('Higado con letericia','Papaploquelite').
enfermedad('Higado con letericia','Achicoria').
enfermedad('Higado con letericia','Berros').
enfermedad('Higado con letericia','Llanten').
enfermedad('Higado con letericia','Retama').
enfermedad('Higado con letericia','Tecomasuchil').
enfermedad('Hipertension alta','Ajo').
enfermedad('Hipertension alta','Esparrago').
enfermedad('Hipertension alta','Alpiste').
enfermedad('Hipertension alta','Murdago').
enfermedad('Hipertension baja','Miel').
enfermedad('Hipertension baja','Nuez de kola').
enfermedad('Hipertension baja','Crategus').
enfermedad('Hipertension baja','Acedera').
enfermedad('Hipo','Anis').
enfermedad('Hipo','Hinojo').
enfermedad('Hipo','Tila').
enfermedad('Hipo','Valleriana').
enfermedad('Hiterismo','Azahar').
enfermedad('Hiterismo','Beleño').
enfermedad('Hiterismo','Gelsemio').
enfermedad('Hiterismo','Tila').
enfermedad('Hiterismo','Valeriana').
enfermedad('Insomnio','Pasiflora').
enfermedad('Insomnio','Azahar').
enfermedad('Insomnio','Menta').
enfermedad('Insomnio','Manzanilla').
enfermedad('Insomnio','Lechuga').
enfermedad('Insomnio','Tila').
enfermedad('Intestino','Genciana').
enfermedad('Intestino','Melisa').
enfermedad('Impotencia sexual','Yohimbo').
enfermedad('Impotencia sexual','Damiana').
enfermedad('Impotencia sexual','Nuez vomica').
enfermedad('Impotencia sexual','Aguacate').
enfermedad('Jaqueca','Manzanilla').
enfermedad('Jaqueca','Acanto').
enfermedad('Jaqueca','Valeriana').
enfermedad('Jaqueca','Tila').
enfermedad('Jaqueca','Chicalote').
enfermedad('Lactancia','Hinojo').
enfermedad('Lactancia','Anis').
enfermedad('Lactancia','Menta').
enfermedad('Lactancia','Perejil').
enfermedad('Lactancia','Zanahoria').
enfermedad('Laringitis','Aconito').
enfermedad('Laringitis','Borraja').
enfermedad('Laringitis','Cebolla').
enfermedad('Laringitis','Rosa').
enfermedad('Laringitis','Benjuilencino').
enfermedad('Leucorrea','Encina').
enfermedad('Leucorrea','Zarzaparrilla').
enfermedad('Leucorrea','Pino').
enfermedad('Leucorrea','Enebro').
enfermedad('Leucorrea','Genciana').
enfermedad('Lombrices','Ajenjo').
enfermedad('Lombrices','Ajo').
enfermedad('Lombrices','Cebolla').
enfermedad('Lombrices','Brionia').
enfermedad('Lombrices','Aguacate').
enfermedad('Lombrices','Papaya').
enfermedad('Lombrices','Epazote').
enfermedad('Lumbago','Avena').
enfermedad('Lumbago','Cebada').
enfermedad('Lumbago','Tomillo').
enfermedad('Lumbago','Vergena').
enfermedad('Llagas','Fenogreco').
enfermedad('Llagas','Eucalipto').
enfermedad('Llagas','Llanton').
enfermedad('Llagas','Sanguinaria').
enfermedad('Malaria','Quina').
enfermedad('Malaria','Girasol').
enfermedad('Malaria','Eucalipto').
enfermedad('Malaria','Cardo').
enfermedad('Menopausia','Azahax').
enfermedad('Menopausia','Hamemelis').
enfermedad('Menopausia','Tila').
enfermedad('Menopausia','Quina roja').
enfermedad('Menstuacion abundante','Azafran').
enfermedad('Menstuacion abundante','Hamamelis').
enfermedad('Menstuacion dolorosa','Belladona').
enfermedad('Menstuacion dolorosa','Anis  Estrella').
enfermedad('Menstuacion escasa','Ruda').
enfermedad('Menstuacion escasa','Ajenjo').
enfermedad('Menstuacion escasa','Mazanilla').
enfermedad('Menstuacion irregular','Apio').
enfermedad('Menstuacion irregular','Hisopo').
enfermedad('Menstuacion irregular','Quina amarilla').
enfermedad('Menstuacion irregular','Sabina').
enfermedad('Menstuacion irregular','Artemisa').
enfermedad('Metorragia (Hemorragia vaginal)','Hamamelis').
enfermedad('Metorragia (Hemorragia vaginal)','Zaopatle').
enfermedad('Metorragia (Hemorragia vaginal)','Perejil').
enfermedad('Metorragia (Hemorragia vaginal)','Cuexnecillo centeno').
enfermedad('Dolor de muelas','Clavo').
enfermedad('Dolor de muelas','Hiedra').
enfermedad('Hemorragias nasales','Ortiga').
enfermedad('Hemorragias nasales','Cola de caballo').
enfermedad('Hemorragias nasales','Ruda').
enfermedad('Hemorragias nasales','Eucalipto').
enfermedad('Nauseas','Anis').
enfermedad('Nauseas','Ajenjo').
enfermedad('Nauseas','Menta').
enfermedad('Nauseas','Salvia').
enfermedad('Neuralgias','Manzanilla').
enfermedad('Neuralgias','Menta').
enfermedad('Neuralgias','Valeriana').
enfermedad('Neuralgias','Boldo').
enfermedad('Neurastenia','Pasiflora').
enfermedad('Neurastenia','Te negro').
enfermedad('Neurastenia','Mate').
enfermedad('Neurastenia','Valeriana').
enfermedad('Nefritis(Inflamacion de los riñones)','Linaza').
enfermedad('Nefritis(Inflamacion de los riñones)','Grama').
enfermedad('Nefritis(Inflamacion de los riñones)','Cebada').
enfermedad('Nefritis(Inflamacion de los riñones)','Llanten').
enfermedad('Nefritis(Inflamacion de los riñones)','Doradilla').
enfermedad('Nefritis(Inflamacion de los riñones)','Esparrago').
enfermedad('Nefritis(Inflamacion de los riñones)','Ruda').
enfermedad('Obesidad','Toronjil').
enfermedad('Obesidad','Marrubio').
enfermedad('Obesidad','Limon').
enfermedad('Obesidad','Malva').
enfermedad('Obesidad','Esparragos').
enfermedad('Oidos','Boldo').
enfermedad('Oidos','Aceite de oliva').
enfermedad('Oidos','Llanten').
enfermedad('Oidos','Hiedra').
enfermedad('Ojos (Conjuntivitis, irritacion)','Manzanilla').
enfermedad('Ojos (Conjuntivitis, irritacion)','Limon').
enfermedad('Ojos (Conjuntivitis, irritacion)','Hanten').
enfermedad('Ojos (Conjuntivitis, irritacion)','Salvia').
enfermedad('Ojos (Conjuntivitis, irritacion)','Ruda').
enfermedad('Ojos (Conjuntivitis, irritacion)','Rosal').
enfermedad('Paludismo','Ajenjo').
enfermedad('Paludismo','Quina').
enfermedad('Pecas','Berro').
enfermedad('Pecas','Genciana').
enfermedad('Pecas','Rabano').
enfermedad('Pecas','Papaya').
enfermedad('Pies olorosos','Laurel').
enfermedad('Pies olorosos','Encina').
enfermedad('Piquetes de abeja','Miel').
enfermedad('Piquetes de abeja','Perejil').
enfermedad('Piquetes de abeja','Cebolla').
enfermedad('Piquetes de abeja','Puerro').
enfermedad('Piquetes de araña','Fresno').
enfermedad('Piquetes de araña','Ipecacuana').
enfermedad('Piquetes de mosco','Alcanfor'). 
enfermedad('Piquetes de mosco','Perejil').
enfermedad('Piquetes de mosco','Amamelis').
enfermedad('Piquetes de bibora','Anagalida').
enfermedad('Pleurecia','Jengibre').    
enfermedad('Pleurecia','Linaza').
enfermedad('Pleurecia','Cardo').
enfermedad('Pleurecia','Girasol').
enfermedad('Piorrea','Ipecacuana').   
enfermedad('Prostata','Cola de caballo').
enfermedad('Pulmonia','Eucalipto').
enfermedad('Pulmonia','Ocote').    
enfermedad('Pulmonia','Gordolobo').     
enfermedad('Pulmonia','Borraja').
enfermedad('Pulmonia','Sauco').
enfermedad('Quemaduras','Linaza Cataplasma').
enfermedad('Quemaduras','Cebolla').
enfermedad('Quemaduras','Hiedra').
enfermedad('Quemaduras','Gordolobo').
enfermedad('Raquitismo','Nogal').
enfermedad('Reumatismo','Ajo').
enfermedad('Reumatismo','Apio').
enfermedad('Reumatismo','Borraja').
enfermedad('Reumatismo','Gobernadora').
enfermedad('Reumatismo','Pino').
enfermedad('Reumatismo','Romero').
enfermedad('Reumatismo','Sanguinaria').
enfermedad('Reumatismo','Maxrubio').
enfermedad('Reumatismo','Tabaco').
enfermedad('Riñones','Cabellos de elote').
enfermedad('Riñones','Cola de caballo').
enfermedad('Riñones','Apio').
enfermedad('Ronquera','Eucalipto').
enfermedad('Ronquera','Pino').
enfermedad('Ronquera','Gordolobo').
enfermedad('Sabañones','Ajo').
enfermedad('Sabañones','Cebolla').
enfermedad('San vito (Mal de)','Estafiate').
enfermedad('San vito (Mal de)','Valeriana').
enfermedad('Sarampion','Borraja').
enfermedad('Sarampion','Ortiga').
enfermedad('Sarampion','Sauco').
enfermedad('Sarna','Ajo').
enfermedad('Sarna','Alcanfor').
enfermedad('Sarna','Menta').
enfermedad('Sarna','Tomillo').
enfermedad('Sarna','Romero').
enfermedad('Sarpullido','Encina').
enfermedad('Sarpullido','Salvia').
enfermedad('Sarpullido','Tila').
enfermedad('Sed','Limon').
enfermedad('Sed','Tamarindo').
enfermedad('Sed','Pirul').
enfermedad('Solitaria','Semilla de calabaza').
enfermedad('Solitaria','Granado').
enfermedad('Solitaria','Coquito de aceite').
enfermedad('Solitaria','Helecho macho').
enfermedad('Sudoracion excesiva','Encina').
enfermedad('Tifoidea','Alcanfor').
enfermedad('Tifoidea','Borraja').
enfermedad('Tifoidea','Quina').
enfermedad('Tifoidea','Canela').
enfermedad('Tifoidea','Romero').
enfermedad('Tifoidea','Salvia').
enfermedad('Tiña','Berro').
enfermedad('Tiña','Tila').
enfermedad('Tiña','Tamarindo').
enfermedad('Tiña','Salvia').
enfermedad('Tos','Eucalipto').
enfermedad('Tos','Capulin').
enfermedad('Tos','Cedron').
enfermedad('Tos','Salvia').
enfermedad('Tos','Malva').
enfermedad('Tos','Marrubio').
enfermedad('Tos Ferina','Gelsemio').
enfermedad('Tos Ferina','Quina').
enfermedad('Tos Ferina','Rabano').
enfermedad('Tos Ferina','Violeta').
enfermedad('Tuberculosis','Jugo de vastago de platano morado').
enfermedad('Tuberculosis','Mastuerso').
enfermedad('Tuberculosis','Berro').
enfermedad('Tuberculosis','Ajo').
enfermedad('Tuberculosis','Eucalipto').
enfermedad('Tuberculosis','Pirul').
enfermedad('Tuberculosis','Pino').
enfermedad('Tuberculosis','Roble').
enfermedad('Ulcera','Cuachalalate').
enfermedad('Ulcera','Sanguinaria').
enfermedad('Ulcera','Cola de caballo').
enfermedad('Ulcera','Girasol').
enfermedad('Urticaria','Limon').
enfermedad('Urticaria','Ruibarbo').
enfermedad('Varices','Hamamelis').
enfermedad('Varices','Castaño de indias').
enfermedad('Varices','Toronjil').
enfermedad('Varices','Llanten').
enfermedad('Vejiga','Apio').
enfermedad('Vejiga','Cipres').
enfermedad('Vejiga','Cola de caballo').
enfermedad('Vejiga','Malva').
enfermedad('Vejiga','Ortiga').
enfermedad('Verrugas','Leche de higuera').
enfermedad('Verrugas','Cebolla').
enfermedad('Verrugas','Nogal').
enfermedad('Vertigos','Albahaca').
enfermedad('Vertigos','Espino').
enfermedad('Vomitos','Menta').
enfermedad('Vomitos','Tila').
enfermedad('Vomitos','Marrubio').
enfermedad('Vomitos','Valeriana').
enfermedad('Vomitos','Salvia').
enfermedad('Voz','Cilantro').
enfermedad('Voz','Ajo').
enfermedad('Voz','Limon').
enfermedad('Voz','Pino').

%Botiquin
botiquin('Anis estrella').
botiquin('Menta').
botiquin('Arnica').
botiquin('Salvia').
botiquin('Tila').
botiquin('Eucalipto').
botiquin('Yierbabuena').
botiquin('Manzanilla').
botiquin('Cola de caballo').
botiquin('Romero').
botiquin('Toronjil').
botiquin('Sanguinaria').
botiquin('Linaza').
botiquin('Hamamelis').
botiquin('Zarzaparrilla').
botiquin('Boldo').
botiquin('Diente de leon').
botiquin('Azahar').
botiquin('Malva').
botiquin('Marrubio').
botiquin('Rosal').

%Significad
significa('Afrodisiaca','exita el apetito sexual').
significa('Analgesica','quita o modera el dolor').
significa('Anestesica','insensibiliza el cuerpo').
significa('Antidiarreica','controla diarreas').
significa('Antiespasmodica','controla espasmos nerviosos').
significa('Antiflogistica','ayuda con inflamaciones').
significa('Antipiretica','quita la fiebre').
significa('Antiseptica','mata los tejidos').
significa('Aperitiva','deseo de comer').
significa('Astringente','contrae los tejidos').
significa('Carminativa','evita formacion de gases').
significa('Colagoga','ayuda a expulsar la bilis').
significa('Depurativa','limpia y purifica la sangre').
significa('Diaforetica','provoca sudoracion como cochino').
significa('Digestiva','favorece a la digestion').
significa('Diuretica','provoca la orina').
significa('Emetica','provoca nauseas y vomitos').
significa('Emenagoga','activa la menstruacion').
significa('Estupefaciente','ayuda a tranquilizar').
significa('Hemostatica','detiene las hemorragias').
significa('Hepatica','ayuda al higado').
significa('Laxante','purga sin provocar diarrea').
significa('Pectoral','ayuda al pecho').
significa('Sedante','calma dolores intestinales').
significa('Tonica','fortalece el organismo').
significa('Toxica','es venenosa').
significa('Vermifuga','expulsa gusanos intestinales').
significa('Vulneraria','cura llagas y heridas').
%Origen
% Hechos sobre el origen de las plantas
origen('Digitaria', 'África, Asia, América, Australia').
origen('Digitalis purpura', 'Europa occidental y central').
origen('Opio', 'Suroeste de Asia').
origen('Ipeca', 'América del Sur, principalmente Brasil').
origen('Nuez vomica', 'Sur de Asia y sudeste asiático').
origen('Eleboro blanco', 'Europa, Asia y América del Norte').
origen('Colchico', 'Europa y partes de Asia occidental').
origen('Belladona', 'Europa, Asia occidental y norte de África').
origen('Quina', 'América del Sur, especialmente de los Andes').
origen('Cacao', 'Región amazónica de Sudamérica, también se cultiva en otras partes tropicales').
origen('Retama', 'Mediterráneo occidental, sur de España y norte de África').
origen('Coca', 'América del Sur, especialmente de los Andes').
origen('Peyote', 'Norte de México y suroeste de Estados Unidos').
origen('Efedra', 'Varios lugares del mundo, incluyendo América del Norte, América del Sur, Europa, África y Asia').
origen('Barbasco', 'México y América Central').
origen('Nenúfar amarillo', 'América, Europa, Asia y África').
origen('Ñame', 'África y Asia tropical').
origen('Artemisa', 'Diferentes regiones del mundo, incluyendo Europa, Asia, África y América del Norte').
origen('Semilla de yute', 'Subcontinente indio').
origen('Toloache', 'América del Norte y América del Sur').
origen('Eucalipto', 'Australia').
origen('Rosal', 'Asia').
origen('Abrojo', 'América del Sur').
origen('Acanto', 'Región mediterránea').
origen('Aceitilla', 'América, especialmente América del Norte y América Central').
origen('Achicoria', 'Europa, Asia y África').
origen('Diente de león', 'Europa y Asia').
origen('Doradilla', 'América del Norte').
origen('Ricino', 'África, Asia, ahora se encuentra en todo el mundo').
origen('Romero', 'Región mediterránea').
origen('Sauce', 'Regiones templadas y frías del hemisferio norte').
origen('Amapola', 'Suroeste de Asia').
origen('Manzanilla', 'Europa y Asia occidental').

%producen_medicamentos
producen_medicamentos('Digitaria').
 producen_medicamentos('Opio').
 producen_medicamentos('Ipeca ').
 producen_medicamentos('Nuez vomica').
 producen_medicamentos('Eleboro blanco').
 producen_medicamentos('Colchico').
 producen_medicamentos('Belladona').
 producen_medicamentos('Quina').
 producen_medicamentos('Cacao').
 producen_medicamentos('Retama').
 producen_medicamentos('Coca').
 producen_medicamentos('Peyote').
 producen_medicamentos('Efedra').
 producen_medicamentos('Barbasco').
 producen_medicamentos('Nenufar amarillo').
 producen_medicamentos('Ñame').
 producen_medicamentos('Artemisa').
 producen_medicamentos('Semilla de yute').
 producen_medicamentos('Toloache').
 producen_medicamentos('Eucalipto').
 producen_medicamentos('Rosal').

medicamento('Digitaria','Digitalina').
medicamento('Opio','Morfina').
medicamento('Opio','Codeina').
medicamento('Ipeca','Emetina').
medicamento('Nuez vomica','Estricnina').
medicamento('Eleboro blanco','Veratrina').
medicamento('Colchico','Colchicina').
medicamento('Belladona','Atropina').
medicamento('Quina','Quinina').
medicamento('Cacao','Teobromina').
medicamento('Retama','Esparteina').
medicamento('Coca','Cocaina').
medicamento('Peyote','Mezcalina').
medicamento('Efedra','Efedrina').
medicamento('Barbasco','Hormonas').
medicamento('Nenufar amarillo','Lutenurina').
medicamento('Ñame','Diosponina').
medicamento('Artemisa','Tauremisina').
medicamento('Semilla de yute','Olitorisida').
medicamento('Toloache','Acido lisergico').
medicamento('Eucalipto','Eucaliptol').
medicamento('Rosal','Vitamina C').
medicamento('Rosal','Quercitrina').
% Hechos sobre los efectos secundarios de los medicamentos
efecto_secundario('Digitalina', ['Náuseas', 'Vómitos', 'Dolores de cabeza', 'Confusión', 'Visión borrosa', 'Ritmo cardíaco irregular', 'Intoxicación digital']).
efecto_secundario('Morfina', ['Somnolencia', 'Mareos', 'Náuseas', 'Vómitos', 'Estreñimiento', 'Depresión respiratoria', 'Adicción']).
efecto_secundario('Codeina', ['Somnolencia', 'Mareos', 'Náuseas', 'Vómitos', 'Estreñimiento', 'Depresión respiratoria', 'Adicción']).
efecto_secundario('Emetina', ['Náuseas', 'Vómitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Daño al corazón en dosis altas']).
efecto_secundario('Estricnina', ['Convulsiones', 'Rigidez muscular extrema', 'Aumento de la presión arterial', 'Taquicardia', 'Muerte']).
efecto_secundario('Veratrina', ['Náuseas', 'Vómitos', 'Dolor abdominal', 'Diarrea', 'Mareos', 'Debilidad muscular', 'Convulsiones en dosis altas']).
efecto_secundario('Colchicina', ['Náuseas', 'Vómitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Disminución de los glóbulos blancos', 'Neuropatía periférica']).
efecto_secundario('Atropina', ['Boca seca', 'Visión borrosa', 'Aumento de la frecuencia cardíaca', 'Retención urinaria', 'Estreñimiento', 'Confusión', 'Alucinaciones']).
efecto_secundario('Quinina', ['Trastornos del ritmo cardíaco', 'Sordera', 'Visión borrosa', 'Náuseas', 'Vómitos', 'Diarrea', 'Dolor de cabeza', 'Sudoración', 'Erupciones cutáneas']).
efecto_secundario('Teobromina', ['Nerviosismo', 'Irritabilidad', 'Insomnio', 'Taquicardia', 'Aumento de la micción', 'Temblores musculares']).
efecto_secundario('Esparteina', ['Mareos', 'Confusión', 'Debilidad muscular', 'Náuseas', 'Vómitos', 'Diarrea', 'Disminución de la presión arterial', 'Arritmias cardíacas']).
efecto_secundario('Cocaina', ['Aumento de la frecuencia cardíaca', 'Presión arterial alta', 'Agitación', 'Ansiedad', 'Convulsiones', 'Accidentes cerebrovasculares', 'Infartos de miocardio', 'Muerte']).
efecto_secundario('Mezcalina', ['Náuseas', 'Vómitos', 'Aumento de la presión arterial', 'Dilatación de las pupilas', 'Alucinaciones', 'Cambios en la percepción sensorial']).
efecto_secundario('Efedrina', ['Nerviosismo', 'Agitación', 'Insomnio', 'Aumento de la presión arterial', 'Palpitaciones cardíacas', 'Temblores musculares', 'Sudoración', 'Mareos']).
efecto_secundario('Hormonas', ['Cambios en el estado de ánimo', 'Aumento de peso', 'Retención de líquidos', 'Cambios en la libido', 'Riesgo aumentado de coágulos sanguíneos']).
efecto_secundario('Lutenurina', ['Irritación en el lugar de la inyección', 'Dolor de cabeza', 'Cambios en el estado de ánimo', 'Cambios en el apetito', 'Acné', 'Aumento del vello facial']).
efecto_secundario('Diosponina', ['Malestar estomacal', 'Diarrea', 'Náuseas', 'Vómitos', 'Dolor de cabeza', 'Mareos', 'Erupciones cutáneas']).
efecto_secundario('Tauremisina', ['Dolor de cabeza', 'Mareos', 'Náuseas', 'Vómitos', 'Diarrea', 'Dolor abdominal', 'Debilidad muscular', 'Temblores']).
efecto_secundario('Olitorisida', ['Irritación en el tracto gastrointestinal', 'Náuseas', 'Vómitos', 'Diarrea', 'Dolor abdominal', 'Mareos']).
efecto_secundario('Ácido lisérgico', ['Alucinaciones', 'Cambios en la percepción sensorial', 'Ansiedad', 'Paranoia', 'Aumento del ritmo cardíaco', 'Aumento de la presión arterial']).
efecto_secundario('Eucaliptol', ['Irritación en la garganta y los pulmones', 'Náuseas', 'Vómitos', 'Diarrea', 'Convulsiones en dosis altas']).
efecto_secundario('Vitamina C', ['Malestar estomacal', 'Diarrea', 'Náuseas', 'Vómitos', 'Dolor de cabeza', 'Acidez estomacal', 'Riesgo aumentado de cálculos renales']).
efecto_secundario('Quercitrina', ['Náuseas', 'Vómitos', 'Diarrea', 'Dolor abdominal', 'Reacciones alérgicas']).
